package app.goals

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.net.Uri
import android.text.TextPaint
import android.text.TextUtils
import android.widget.RemoteViews

// ودجت 1×1: مربع للعادات. عادة واحدة أو عدة عادات خلف بعضها؛ لمس الدائرة = إنجاز اليوم، ولمس أسفل المربع = العادة التالية
class HabitWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) {
        for (id in ids) update(c, m, id)
    }

    override fun onAppWidgetOptionsChanged(c: Context, m: AppWidgetManager, id: Int, newOptions: android.os.Bundle) {
        update(c, m, id)
    }

    override fun onDeleted(c: Context, ids: IntArray) {
        val e = c.getSharedPreferences("hw", 0).edit()
        for (id in ids) {
            e.remove("w" + id)
            e.remove("i" + id)
        }
        e.apply()
    }

    override fun onReceive(c: Context, i: Intent) {
        super.onReceive(c, i)
        val id = i.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, -1)
        if (id < 0) return
        when (i.action) {
            ACT_NEXT -> {
                val sp = c.getSharedPreferences("hw", 0)
                sp.edit().putInt("i" + id, sp.getInt("i" + id, 0) + 1).apply()
                update(c, AppWidgetManager.getInstance(c), id)
            }
            ACT_TOGGLE -> {
                val list = habitsFor(c, id)
                if (list.isNotEmpty()) {
                    val idx = c.getSharedPreferences("hw", 0).getInt("i" + id, 0)
                    val h = list[Math.floorMod(idx, list.size)]
                    HabitsData.toggleToday(c, h.id)
                    GoalsWidget.refresh(c)
                    refreshAll(c)
                    MainActivity.notifyDataChanged()
                    MainActivity.notifyFocusChanged()
                }
            }
        }
    }

    companion object {
        const val ACT_NEXT = "app.goals.HW_NEXT"
        const val ACT_TOGGLE = "app.goals.HW_TOGGLE"

        fun refreshAll(c: Context) {
            val m = AppWidgetManager.getInstance(c)
            for (id in m.getAppWidgetIds(ComponentName(c, HabitWidget::class.java))) update(c, m, id)
        }

        fun saveSelection(c: Context, id: Int, ids: List<String>) {
            c.getSharedPreferences("hw", 0).edit().putString("w" + id, ids.joinToString(",")).putInt("i" + id, 0).apply()
        }

        // بدون اختيار = كل العادات
        fun habitsFor(c: Context, id: Int): List<HabitInfo> {
            val all = HabitsData.all(c)
            val sel = (c.getSharedPreferences("hw", 0).getString("w" + id, "") ?: "").split(",").filter { it.isNotBlank() }
            if (sel.isEmpty()) return all
            return sel.mapNotNull { s -> all.firstOrNull { it.id == s } }
        }

        private fun pi(c: Context, action: String, id: Int): PendingIntent {
            val i = Intent(c, HabitWidget::class.java)
            i.action = action
            i.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
            i.data = Uri.parse("habitw://" + action + "/" + id)
            return PendingIntent.getBroadcast(c, id, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        }

        // لمس الدائرة: يفتح شاشة الاحتفال الشفافة التي تبدّل الإنجاز وتعرض التأثير
        private fun toggleIntent(c: Context, id: Int, habitId: String): PendingIntent {
            val i = Intent(c, CelebrateActivity::class.java)
            i.putExtra("ht", habitId)
            i.data = Uri.parse("habitw://toggle/" + id + "/" + Uri.encode(habitId))
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
            return PendingIntent.getActivity(c, id + 7000, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        }

        private fun openHabits(c: Context): PendingIntent {
            val i = Intent(c, MainActivity::class.java)
            i.putExtra("tab", "habits")
            i.data = Uri.parse("habitw://open")
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            return PendingIntent.getActivity(c, 0, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        }

        fun update(c: Context, mgr: AppWidgetManager, id: Int) {
            Lang.load(c)
            val list = habitsFor(c, id)
            val sp = c.getSharedPreferences("hw", 0)
            val idx = if (list.isEmpty()) 0 else Math.floorMod(sp.getInt("i" + id, 0), list.size)
            // نرسم الصورة بمقاس الخلية الفعلي (أيقونة + اسمها) لتملأها بدل مربع صغير في وسطها
            val o = mgr.getAppWidgetOptions(id)
            val d = c.resources.displayMetrics.density
            val wDp = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 74).coerceIn(40, 220)
            val hDp = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 96).coerceIn(40, 260)
            val rv = RemoteViews(c.packageName, R.layout.habit_widget)
            rv.setImageViewBitmap(R.id.hw_img, draw(list, idx, (wDp * d).toInt(), (hDp * d).toInt()))
            if (list.isEmpty()) {
                rv.setOnClickPendingIntent(R.id.hw_top, openHabits(c))
                rv.setOnClickPendingIntent(R.id.hw_bottom, openHabits(c))
            } else {
                val tg = toggleIntent(c, id, list[idx].id)
                rv.setOnClickPendingIntent(R.id.hw_top, tg)
                rv.setOnClickPendingIntent(R.id.hw_bottom, if (list.size > 1) pi(c, ACT_NEXT, id) else tg)
            }
            mgr.updateAppWidget(id, rv)
        }

        private fun draw(list: List<HabitInfo>, idx: Int, w: Int, h: Int): Bitmap {
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val cv = Canvas(bmp)
            val surface = Color.parseColor("#171222")
            val line = Color.parseColor("#352d43")
            val fg = Color.parseColor("#f5efe6")
            val muted = Color.parseColor("#aaa3b5")
            val gold = Color.parseColor("#d4a95a")
            val ok = Color.parseColor("#65b891")
            val u = Math.min(w / 240f, h / 280f)
            val p = Paint(Paint.ANTI_ALIAS_FLAG)
            val card = RectF(2f, 2f, w - 2f, h - 2f)
            p.style = Paint.Style.FILL
            p.color = surface
            cv.drawRoundRect(card, 44f * u, 44f * u, p)
            p.style = Paint.Style.STROKE
            p.strokeWidth = 3f
            p.color = line
            cv.drawRoundRect(card, 44f * u, 44f * u, p)

            val tp = TextPaint(Paint.ANTI_ALIAS_FLAG)
            tp.textAlign = Paint.Align.CENTER
            if (list.isEmpty()) {
                tp.color = muted
                tp.textSize = 28f * u
                tp.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                val t = TextUtils.ellipsize(T("أضف عادة", "Add a habit"), tp, w - 40f * u, TextUtils.TruncateAt.END).toString()
                cv.drawText(t, w / 2f, h / 2f + 10f * u, tp)
                return bmp
            }
            val hb = list[idx]
            val cx = w / 2f
            val cy = h * 0.30f
            val r = Math.min(w * 0.19f, h * 0.14f)
            p.style = Paint.Style.STROKE
            p.strokeWidth = Math.max(6f, r * 0.23f)
            p.strokeCap = Paint.Cap.ROUND
            p.strokeJoin = Paint.Join.ROUND
            if (hb.done) {
                p.color = ok
                cv.drawCircle(cx, cy, r, p)
                val k = r / 44f
                val chk = Path()
                chk.moveTo(cx - 18f * k, cy + 2f * k)
                chk.lineTo(cx - 6f * k, cy + 15f * k)
                chk.lineTo(cx + 20f * k, cy - 14f * k)
                cv.drawPath(chk, p)
            } else {
                p.color = if (hb.due) gold else line
                cv.drawCircle(cx, cy, r, p)
                if (hb.streak > 0) {
                    tp.color = if (hb.due) gold else muted
                    tp.textSize = r * 1.05f
                    tp.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
                    cv.drawText(hb.streak.toString(), cx, cy + r * 0.36f, tp)
                }
            }
            tp.color = if (hb.due) fg else muted
            tp.textSize = 30f * u
            tp.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            val title = TextUtils.ellipsize(hb.title, tp, w - 32f * u, TextUtils.TruncateAt.END).toString()
            cv.drawText(title, cx, h * 0.66f, tp)

            // صف النقاط: مؤشّر العادات إن كانت أكثر من واحدة، وإلا آخر 7 أيام للعادة
            val n = if (list.size > 1) Math.min(list.size, 7) else 7
            val gap = Math.min(26f * u, w * 0.84f / 6f)
            val x0 = cx - gap * (n - 1) / 2f
            val y = h * 0.85f
            val dr = 7f * u
            for (k in 0 until n) {
                val x = x0 + gap * k
                if (list.size > 1) {
                    val cur = k == Math.min(idx, 6)
                    p.style = Paint.Style.FILL
                    p.color = if (cur) gold else line
                    cv.drawCircle(x, y, if (cur) dr * 1.15f else dr * 0.85f, p)
                } else {
                    when (hb.week[k]) {
                        1 -> {
                            p.style = Paint.Style.FILL
                            p.color = ok
                            cv.drawCircle(x, y, dr, p)
                        }
                        2 -> {
                            p.style = Paint.Style.STROKE
                            p.strokeWidth = 2.5f * u
                            p.color = line
                            cv.drawCircle(x, y, dr * 0.85f, p)
                        }
                        3 -> {
                            p.style = Paint.Style.STROKE
                            p.strokeWidth = 2.5f * u
                            p.color = gold
                            cv.drawCircle(x, y, dr * 0.85f, p)
                        }
                        else -> {
                            p.style = Paint.Style.FILL
                            p.color = Color.argb(70, 53, 45, 67)
                            cv.drawCircle(x, y, dr * 0.6f, p)
                        }
                    }
                }
            }
            return bmp
        }
    }
}
