package app.goals

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebMessage
import android.net.Uri
import org.json.JSONObject
import android.os.Build
import java.lang.ref.WeakReference

class MainActivity : Activity() {
    companion object {
        private var current: WeakReference<MainActivity>? = null
        fun notifyDataChanged() {
            current?.get()?.postWebEvent("data_changed")
        }

        fun gotoTab(tab: String) {
            current?.get()?.postWebEvent("focus_returned", mapOf("tab" to tab))
        }

        fun notifyFocusChanged() {
            current?.get()?.let { a ->
                a.postWebEvent("focus_changed", mapOf("state" to (FocusStore.session?.state ?: "none"), "balance" to FocusStore.fmtFloor(FocusStore.bal)))
            }
        }
    }

    private var web: WebView? = null
    private var focusHost: SwipeFrame? = null
    private var focusPage: FocusPage? = null
    private var focusVisible = false
    private var started = false
    private var pageReady = false
    private val pendingEvents = ArrayList<String>()

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        current = WeakReference(this)
        FocusWatchdog.schedule(this)
        AutoBackup.runIfDue(this)
        applySystemBars()
        val w = WebView(this)
        w.setBackgroundColor(Color.parseColor("#0a0712"))
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.addJavascriptInterface(Bridge(this), "Android")
        w.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String) {
                super.onPageFinished(view, url)
                pageReady = true
                val queued = pendingEvents.toList()
                pendingEvents.clear()
                queued.forEach { sendWebMessage(it) }
            }
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val u = request.url
                if (u.scheme == "http" || u.scheme == "https") {
                    startActivity(Intent(Intent.ACTION_VIEW, u))
                    return true
                }
                return false
            }
        }
        w.loadUrl("file:///android_asset/index.html")
        // الشاشة: الويب في الخلفية، وفوقه صفحة Focus الأصلية تترك شريط الأقسام السفلي ظاهرًا
        val fl = android.widget.FrameLayout(this)
        fl.setBackgroundColor(Color.parseColor("#0a0712"))
        fl.addView(w, android.widget.FrameLayout.LayoutParams(android.view.ViewGroup.LayoutParams.MATCH_PARENT, android.view.ViewGroup.LayoutParams.MATCH_PARENT))
        val fh = SwipeFrame(this) { side -> web?.evaluateJavascript("swipeTab('" + side + "')", null) }
        fh.visibility = android.view.View.GONE
        fh.background = AppBgDrawable()
        val lp = android.widget.FrameLayout.LayoutParams(android.view.ViewGroup.LayoutParams.MATCH_PARENT, android.view.ViewGroup.LayoutParams.MATCH_PARENT)
        lp.bottomMargin = (64 * resources.displayMetrics.density).toInt()
        fl.addView(fh, lp)
        setContentView(fl)
        web = w
        focusHost = fh
        val t0 = intent?.getStringExtra("tab")
        if (!t0.isNullOrBlank()) pendingEvents.add(JSONObject().put("type", "focus_returned").put("tab", t0).toString())
    }

    // يظهر الويب شريط الأقسام ويخبرنا بارتفاعه (px CSS = dp) لنترك له مكانه أسفل صفحة Focus
    fun setNavHeight(cssPx: Int) {
        val fh = focusHost ?: return
        val lp = fh.layoutParams as android.widget.FrameLayout.LayoutParams
        lp.bottomMargin = (cssPx.coerceAtLeast(40) * resources.displayMetrics.density).toInt()
        fh.layoutParams = lp
    }

    fun showFocusTab(show: Boolean) {
        val fh = focusHost ?: return
        if (show) {
            if (focusPage == null) {
                val p = FocusPage(this)
                fh.addView(p.build(), android.widget.FrameLayout.LayoutParams(android.view.ViewGroup.LayoutParams.MATCH_PARENT, android.view.ViewGroup.LayoutParams.MATCH_PARENT))
                focusPage = p
            }
            fh.visibility = android.view.View.VISIBLE
            if (!focusVisible) focusPage?.onShow()
            focusVisible = true
        } else {
            fh.visibility = android.view.View.GONE
            if (focusVisible) focusPage?.onHide()
            focusVisible = false
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (focusVisible) focusPage?.onShow(false)
    }

    private fun applySystemBars() {
        val bg = Color.parseColor("#0a0712")
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.setBackgroundColor(bg)
        if (Build.VERSION.SDK_INT >= 29) {
            window.isStatusBarContrastEnforced = false
            window.isNavigationBarContrastEnforced = false
        }
        // Keep light/dark icon appearance managed by the system theme; avoid transient white bars.
        window.decorView.systemUiVisibility = 0
    }

    override fun onResume() {
        super.onResume()
        applySystemBars()
        if (started) postWebEvent("focus_returned")
        started = true
        if (focusVisible) focusPage?.onShow(false)
    }

    // زر/إيماءة الرجوع: تُرجع خطوة داخل التطبيق (نافذة ← قسم سابق) ولا تُغلقه إلا من الصفحة الرئيسية
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        val w = web
        if (w == null || !pageReady) {
            super.onBackPressed()
            return
        }
        w.evaluateJavascript("(function(){try{return (window.goBack&&goBack())?1:0}catch(e){return 0}})()") { r ->
            if (r != "1") super@MainActivity.onBackPressed()
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        val tab = intent.getStringExtra("tab")
        postWebEvent("focus_returned", if (tab.isNullOrBlank()) null else mapOf("tab" to tab))
    }

    fun postWebEvent(type: String, data: Map<String, String>? = null) {
        val payload = JSONObject().put("type", type)
        data?.forEach { (k, v) -> payload.put(k, v) }
        val message = payload.toString()
        val target = web
        if (!pageReady || target == null) { pendingEvents.add(message); return }
        runOnUiThread { sendWebMessage(message) }
    }

    private fun sendWebMessage(message: String) {
        val target = web ?: run { pendingEvents.add(message); return }
        try { target.postWebMessage(WebMessage(message), Uri.parse("*")) }
        catch (_: Exception) { pendingEvents.add(message) }
    }

    override fun onDestroy() {
        if (current?.get() === this) current = null
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        Backup.result(this, requestCode, resultCode, data)
    }
}

class Bridge(private val a: MainActivity) {
    private val c: Context = a

    @JavascriptInterface
    fun load(): String {
        try {
            HabitsData.migrate(c)
        } catch (e: Exception) {
        }
        return c.getSharedPreferences("g", 0).getString("d", "") ?: ""
    }

    @JavascriptInterface
    fun save(s: String) {
        c.getSharedPreferences("g", 0).edit().putString("d", s).apply()
        GoalsWidget.refresh(c)
        HabitWidget.refreshAll(c)
    }

    // تبويب Focus: إظهار/إخفاء الصفحة الأصلية فوق الويب
    @JavascriptInterface
    fun focusTab(show: Int) {
        a.runOnUiThread { a.showFocusTab(show != 0) }
    }

    @JavascriptInterface
    fun navHeight(px: Int) {
        a.runOnUiThread { a.setNavHeight(px) }
    }

    // بدء جلسة Focus لعادة من تبويب العادات
    @JavascriptInterface
    fun focusStart(id: String, title: String, minutes: Int, reward: Double): String {
        val out = arrayOf("err")
        val latch = java.util.concurrent.CountDownLatch(1)
        android.os.Handler(android.os.Looper.getMainLooper()).post {
            try {
                FocusStore.init(a)
                out[0] = FocusStore.startFromHabit(a, id, title, minutes, reward)
                if (out[0] == "ok") MainActivity.notifyFocusChanged()
            } catch (e: Exception) {
            }
            latch.countDown()
        }
        try {
            latch.await(2, java.util.concurrent.TimeUnit.SECONDS)
        } catch (e: Exception) {
        }
        return out[0]
    }

    @JavascriptInterface
    fun exportBackup() {
        a.runOnUiThread { Backup.export(a) }
    }

    @JavascriptInterface
    fun importBackup() {
        a.runOnUiThread { Backup.importFile(a) }
    }

    // مكافأة Focus عند إنجاز مهمة من واجهة الويب (تُنفَّذ على الخيط الرئيسي لتجنّب التعارض مع الخدمة)
    @JavascriptInterface
    fun focusReward(amount: Double, title: String, ref: String): Double {
        val out = DoubleArray(1)
        val latch = java.util.concurrent.CountDownLatch(1)
        android.os.Handler(android.os.Looper.getMainLooper()).post {
            try {
                FocusStore.init(a)
                out[0] = FocusStore.add(amount, title, ref, false)
            } catch (e: Exception) {
            }
            latch.countDown()
        }
        try {
            latch.await(2, java.util.concurrent.TimeUnit.SECONDS)
        } catch (e: Exception) {
        }
        return out[0]
    }

    @JavascriptInterface
    fun openFocus(fromTab: String) {
        a.runOnUiThread {
            a.startActivity(Intent(a, FocusActivity::class.java).putExtra("from", "tab").putExtra("tab", fromTab))
        }
    }

    @JavascriptInterface
    fun getPref(k: String): Int = if (Store.flag(c, k)) 1 else 0

    @JavascriptInterface
    fun setPref(k: String, v: Int) {
        Store.setFlag(c, k, v != 0)
    }
}

// حاوية صفحة Focus: تلتقط السحب الأفقي لتبديل الأقسام (r = إصبع لليمين، l = لليسار) وتترك الرأسي للتمرير
class SwipeFrame(c: Context, private val onSwipe: (String) -> Unit) : android.widget.FrameLayout(c) {
    private var x0 = 0f
    private var y0 = 0f
    private var fired = false
    private val slop = android.view.ViewConfiguration.get(c).scaledTouchSlop

    override fun onInterceptTouchEvent(e: android.view.MotionEvent): Boolean {
        when (e.actionMasked) {
            android.view.MotionEvent.ACTION_DOWN -> {
                x0 = e.x
                y0 = e.y
                fired = false
            }
            android.view.MotionEvent.ACTION_MOVE -> {
                val dx = e.x - x0
                val dy = e.y - y0
                if (Math.abs(dx) > slop * 3 && Math.abs(dx) > Math.abs(dy) * 1.6f) return true
            }
        }
        return false
    }

    override fun onTouchEvent(e: android.view.MotionEvent): Boolean {
        if (e.actionMasked == android.view.MotionEvent.ACTION_UP && !fired) {
            val dx = e.x - x0
            if (Math.abs(dx) > 70f * resources.displayMetrics.density) {
                fired = true
                onSwipe(if (dx > 0) "r" else "l")
            }
        }
        return true
    }
}
