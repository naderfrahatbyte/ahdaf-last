package app.goals

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebMessage
import android.net.Uri
import org.json.JSONObject
import android.os.Build
import java.lang.ref.WeakReference

class MainActivity : Activity() {
    companion object {
        private var current: WeakReference<MainActivity>? = null
        fun notifyDataChanged() {
            current?.get()?.postWebEvent("data_changed")
        }

        fun gotoTab(tab: String) {
            current?.get()?.postWebEvent("focus_returned", mapOf("tab" to tab))
        }

        fun notifyFocusChanged() {
            current?.get()?.let { a ->
                a.postWebEvent("focus_changed", mapOf("state" to (FocusStore.session?.state ?: "none"), "balance" to FocusStore.fmtFloor(FocusStore.bal)))
            }
        }
    }

    private var web: WebView? = null
    private var focusHost: SwipeFrame? = null
    private var focusPage: FocusPage? = null
    private var focusVisible = false
    private var started = false
    private var pageReady = false
    private val pendingEvents = ArrayList<String>()

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        current = WeakReference(this)
        CrashLog.install(this)
        DataSafe.onStart(this)
        FocusWatchdog.schedule(this)
        Reminders.reschedule(this)
        AutoBackup.runIfDue(this)
        if (CrashLog.takeNotice(this)) {
            android.widget.Toast.makeText(this, T("حدث عطل سابق، يمكنك نسخ تقريره من الإعدادات", "A previous crash was recorded; copy its report from Settings"), android.widget.Toast.LENGTH_LONG).show()
        }
        DataSafe.takeRecoveredMessage(this)?.let {
            android.widget.Toast.makeText(this, T("تعذّرت قراءة بياناتك فاستُعيدت آخر نقطة سليمة: ", "Your data was unreadable; restored the last good point: ") + it, android.widget.Toast.LENGTH_LONG).show()
        }
        applySystemBars()
        val w = WebView(this)
        w.setBackgroundColor(Color.parseColor("#0a0712"))
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.addJavascriptInterface(Bridge(this), "Android")
        w.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String) {
                super.onPageFinished(view, url)
                pageReady = true
                val queued = pendingEvents.toList()
                pendingEvents.clear()
                queued.forEach { sendWebMessage(it) }
            }
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val u = request.url
                if (u.scheme == "http" || u.scheme == "https") {
                    startActivity(Intent(Intent.ACTION_VIEW, u))
                    return true
                }
                return false
            }
        }
        w.loadUrl("file:///android_asset/index.html")
        // الشاشة: الويب في الخلفية، وفوقه صفحة Focus الأصلية تترك شريط الأقسام السفلي ظاهرًا
        val fl = android.widget.FrameLayout(this)
        fl.setBackgroundColor(Color.parseColor("#0a0712"))
        fl.addView(w, android.widget.FrameLayout.LayoutParams(android.view.ViewGroup.LayoutParams.MATCH_PARENT, android.view.ViewGroup.LayoutParams.MATCH_PARENT))
        val fh = SwipeFrame(this) { side -> web?.evaluateJavascript("swipeTab('" + side + "',true)", null) }
        fh.visibility = android.view.View.GONE
        fh.background = AppBgDrawable()
        val lp = android.widget.FrameLayout.LayoutParams(android.view.ViewGroup.LayoutParams.MATCH_PARENT, android.view.ViewGroup.LayoutParams.MATCH_PARENT)
        lp.bottomMargin = (64 * resources.displayMetrics.density).toInt()
        fl.addView(fh, lp)
        setContentView(fl)
        web = w
        focusHost = fh
        val t0 = intent?.getStringExtra("tab")
        if (!t0.isNullOrBlank()) pendingEvents.add(JSONObject().put("type", "focus_returned").put("tab", t0).toString())
    }

    // إذن الإشعارات (أندرويد 13+) عند ضبط أول تذكير
    fun askNotifPermission() {
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED
        ) {
            try {
                requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 5502)
            } catch (e: Exception) {
            }
        }
    }

    // يظهر الويب شريط الأقسام ويخبرنا بارتفاعه (px CSS = dp) لنترك له مكانه أسفل صفحة Focus
    fun setNavHeight(cssPx: Int) {
        val fh = focusHost ?: return
        val lp = fh.layoutParams as android.widget.FrameLayout.LayoutParams
        lp.bottomMargin = (cssPx.coerceAtLeast(40) * resources.displayMetrics.density).toInt()
        fh.layoutParams = lp
    }

    fun showFocusTab(show: Boolean) {
        val fh = focusHost ?: return
        if (show) {
            if (focusPage == null) {
                val p = FocusPage(this)
                fh.addView(p.build(), android.widget.FrameLayout.LayoutParams(android.view.ViewGroup.LayoutParams.MATCH_PARENT, android.view.ViewGroup.LayoutParams.MATCH_PARENT))
                focusPage = p
            }
            fh.animate().cancel()
            if (!focusVisible) {
                fh.translationX = 0f
                fh.alpha = 0f
                fh.visibility = android.view.View.VISIBLE
                fh.animate().alpha(1f).setDuration(200).start()
                focusPage?.onShow()
            } else {
                fh.alpha = 1f
                fh.visibility = android.view.View.VISIBLE
            }
            focusVisible = true
        } else {
            if (focusVisible) {
                focusPage?.onHide()
                fh.animate().cancel()
                fh.animate().alpha(0f).setDuration(150).withEndAction {
                    if (!focusVisible) fh.visibility = android.view.View.GONE
                }.start()
            } else {
                fh.visibility = android.view.View.GONE
            }
            focusVisible = false
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (focusVisible) focusPage?.onShow(false)
    }

    private fun applySystemBars() {
        val bg = Color.parseColor("#0a0712")
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.setBackgroundColor(bg)
        if (Build.VERSION.SDK_INT >= 29) {
            window.isStatusBarContrastEnforced = false
            window.isNavigationBarContrastEnforced = false
        }
        // Keep light/dark icon appearance managed by the system theme; avoid transient white bars.
        window.decorView.systemUiVisibility = 0
    }

    override fun onResume() {
        super.onResume()
        applySystemBars()
        if (started) postWebEvent("focus_returned")
        started = true
        if (focusVisible) focusPage?.onShow(false)
    }

    // زر/إيماءة الرجوع: تُرجع خطوة داخل التطبيق (نافذة ← قسم سابق) ولا تُغلقه إلا من الصفحة الرئيسية
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        val w = web
        if (w == null || !pageReady) {
            super.onBackPressed()
            return
        }
        w.evaluateJavascript("(function(){try{return (window.goBack&&goBack())?1:0}catch(e){return 0}})()") { r ->
            if (r != "1") super@MainActivity.onBackPressed()
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        val tab = intent.getStringExtra("tab")
        postWebEvent("focus_returned", if (tab.isNullOrBlank()) null else mapOf("tab" to tab))
    }

    fun postWebEvent(type: String, data: Map<String, String>? = null) {
        val payload = JSONObject().put("type", type)
        data?.forEach { (k, v) -> payload.put(k, v) }
        val message = payload.toString()
        val target = web
        if (!pageReady || target == null) { pendingEvents.add(message); return }
        runOnUiThread { sendWebMessage(message) }
    }

    private fun sendWebMessage(message: String) {
        val target = web ?: run { pendingEvents.add(message); return }
        try { target.postWebMessage(WebMessage(message), Uri.parse("*")) }
        catch (_: Exception) { pendingEvents.add(message) }
    }

    override fun onDestroy() {
        if (current?.get() === this) current = null
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        Backup.result(this, requestCode, resultCode, data)
    }
}

class Bridge(private val a: MainActivity) {
    private val c: Context = a

    @JavascriptInterface
    fun load(): String {
        try {
            HabitsData.migrate(c)
        } catch (e: Exception) {
        }
        return c.getSharedPreferences("g", 0).getString("d", "") ?: ""
    }

    @JavascriptInterface
    fun save(s: String) {
        // WebView saves are untrusted input: never overwrite the last good state with malformed JSON.
        if (s.length > 8 * 1024 * 1024) return
        val parsed = try { org.json.JSONObject(s) } catch (_: Exception) { return }
        val clean = try { DataSafe.sanitize(parsed, false) } catch (_: Exception) { null } ?: return
        // Require a recognizable application payload before committing it.
        if (!clean.has("goals") && !clean.has("loose") && !clean.has("lists") && !clean.has("habits")) return
        val prefs = c.getSharedPreferences("g", 0)
        val committed = prefs.edit().putString("d", clean.toString()).commit()
        if (!committed) return
        GoalsWidget.refresh(c)
        HabitWidget.refreshAll(c)
        Reminders.reschedule(c)
    }

    // تبويب Focus: إظهار/إخفاء الصفحة الأصلية فوق الويب
    @JavascriptInterface
    fun focusTab(show: Int) {
        a.runOnUiThread { a.showFocusTab(show != 0) }
    }

    @JavascriptInterface
    fun askNotif() {
        a.runOnUiThread { a.askNotifPermission() }
    }

    @JavascriptInterface
    fun navHeight(px: Int) {
        a.runOnUiThread { a.setNavHeight(px) }
    }

    // بدء جلسة Focus لعادة من تبويب العادات
    @JavascriptInterface
    fun focusStart(id: String, title: String, minutes: Int, reward: Double): String {
        val out = arrayOf("err")
        val latch = java.util.concurrent.CountDownLatch(1)
        android.os.Handler(android.os.Looper.getMainLooper()).post {
            try {
                FocusStore.init(a)
                out[0] = FocusStore.startFromHabit(a, id, title, minutes, reward)
                if (out[0] == "ok") MainActivity.notifyFocusChanged()
            } catch (e: Exception) {
            }
            latch.countDown()
        }
        try {
            latch.await(2, java.util.concurrent.TimeUnit.SECONDS)
        } catch (e: Exception) {
        }
        return out[0]
    }

    @JavascriptInterface
    fun exportBackup() {
        a.runOnUiThread { Backup.export(a) }
    }

    @JavascriptInterface
    fun importBackup() {
        a.runOnUiThread { Backup.importFile(a) }
    }

    // مكافأة Focus عند إنجاز مهمة من واجهة الويب (تُنفَّذ على الخيط الرئيسي لتجنّب التعارض مع الخدمة)
    @JavascriptInterface
    fun focusReward(amount: Double, title: String, ref: String): Double {
        val out = DoubleArray(1)
        val latch = java.util.concurrent.CountDownLatch(1)
        android.os.Handler(android.os.Looper.getMainLooper()).post {
            try {
                FocusStore.init(a)
                out[0] = FocusStore.add(amount, title, ref, false)
            } catch (e: Exception) {
            }
            latch.countDown()
        }
        try {
            latch.await(2, java.util.concurrent.TimeUnit.SECONDS)
        } catch (e: Exception) {
        }
        return out[0]
    }

    // سحب مكافأة (عند إلغاء عادة من الواجهة)
    @JavascriptInterface
    fun focusRevoke(amount: Double, title: String, ref: String): Double {
        val out = DoubleArray(1)
        val latch = java.util.concurrent.CountDownLatch(1)
        android.os.Handler(android.os.Looper.getMainLooper()).post {
            try {
                FocusStore.init(a)
                out[0] = FocusStore.revoke(amount, title, ref)
                MainActivity.notifyFocusChanged()
            } catch (e: Exception) {
            }
            latch.countDown()
        }
        try {
            latch.await(2, java.util.concurrent.TimeUnit.SECONDS)
        } catch (e: Exception) {
        }
        return out[0]
    }

    @JavascriptInterface
    fun openFocus(fromTab: String) {
        a.runOnUiThread {
            a.startActivity(Intent(a, FocusActivity::class.java).putExtra("from", "tab").putExtra("tab", fromTab))
        }
    }

    @JavascriptInterface
    fun getPref(k: String): Int = if (if (k == "dgo") Reminders.digestOn(c) else Store.flag(c, k)) 1 else 0

    @JavascriptInterface
    fun setPref(k: String, v: Int) {
        Store.setFlag(c, k, v != 0)
        if (k == "rem" || k == "dgo") Reminders.reschedule(c)
    }

    // ---- حماية البيانات: نقاط الاستعادة ----
    @JavascriptInterface
    fun snapshots(): String {
        val arr = org.json.JSONArray()
        for (s in DataSafe.list(c)) {
            arr.put(
                org.json.JSONObject().put("file", s.file).put("label", s.label).put("when", DataSafe.fmtTime(s.ts))
                    .put("goals", s.goals).put("tasks", s.tasks).put("habits", s.habits).put("lists", s.lists)
            )
        }
        return arr.toString()
    }

    private fun onMain(def: Int, f: () -> Int): Int {
        val out = intArrayOf(def)
        val latch = java.util.concurrent.CountDownLatch(1)
        android.os.Handler(android.os.Looper.getMainLooper()).post {
            try {
                out[0] = f()
            } catch (e: Exception) {
            }
            latch.countDown()
        }
        try {
            latch.await(4, java.util.concurrent.TimeUnit.SECONDS)
        } catch (e: Exception) {
        }
        return out[0]
    }

    @JavascriptInterface
    fun snapshotNow(): Int = onMain(0) { if (DataSafe.snapshot(c, T("يدوية", "Manual"))) 1 else 0 }

    @JavascriptInterface
    fun restoreSnapshot(file: String): Int = onMain(0) { if (DataSafe.restore(c, file)) 1 else 0 }

    // ---- معلومات التطبيق وتقرير الأعطال ----
    @JavascriptInterface
    fun appVersion(): String = CrashLog.versionName(c)

    @JavascriptInterface
    fun lastCrash(): String = CrashLog.read(c)

    @JavascriptInterface
    fun logError(m: String) {
        CrashLog.append(c, m)
    }

    @JavascriptInterface
    fun clearCrash() {
        CrashLog.clear(c)
    }

    @JavascriptInterface
    fun copyText(t: String) {
        a.runOnUiThread {
            try {
                val cm = c.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                cm.setPrimaryClip(android.content.ClipData.newPlainText("report", t))
            } catch (e: Exception) {
            }
        }
    }

    @JavascriptInterface
    fun getDigestTime(): String = Reminders.digestTime(c)

    @JavascriptInterface
    fun setDigestTime(v: String) {
        if (Regex("^\\d{2}:\\d{2}$").matches(v)) {
            Reminders.setDigestTime(c, v)
            Reminders.reschedule(c)
        }
    }

    // هل الإشعارات مسموحة فعلًا (إذن + إعداد النظام)؟
    @JavascriptInterface
    fun notifAllowed(): Int =
        if ((c.getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager).areNotificationsEnabled()) 1 else 0

    @JavascriptInterface
    fun openNotifSettings() {
        a.runOnUiThread {
            try {
                if (android.os.Build.VERSION.SDK_INT >= 26) {
                    a.startActivity(Intent(android.provider.Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(android.provider.Settings.EXTRA_APP_PACKAGE, a.packageName))
                }
            } catch (e: Exception) {
            }
        }
    }
}

// حاوية صفحة Focus: تتبع الإصبع أفقيًا مثل ViewPager؛ عند الإفلات تنزلق خارجًا وتكشف الصفحة التي خلفها (r/l = جهة الإصبع)
class SwipeFrame(c: Context, private val onSwipe: (String) -> Unit) : android.widget.FrameLayout(c) {
    private var x0 = 0f
    private var y0 = 0f
    private var lastX = 0f
    private var lastT = 0L
    private var vx = 0f
    private val slop = android.view.ViewConfiguration.get(c).scaledTouchSlop

    // Focus هو آخر قسم: لا يُسمح إلا بالرجوع (في العربية بالإصبع لليسار)
    private fun allowed(dx: Float): Boolean = if (!Lang.en) dx < 0 else dx > 0

    override fun onInterceptTouchEvent(e: android.view.MotionEvent): Boolean {
        when (e.actionMasked) {
            android.view.MotionEvent.ACTION_DOWN -> {
                x0 = e.x
                y0 = e.y
                lastX = e.x
                lastT = e.eventTime
                vx = 0f
            }
            android.view.MotionEvent.ACTION_MOVE -> {
                val dx = e.x - x0
                val dy = e.y - y0
                if (Math.abs(dx) > slop * 3 && Math.abs(dx) > Math.abs(dy) * 1.6f) return true
            }
        }
        return false
    }

    private fun settle(commit: Boolean, dx: Float) {
        val w = width.toFloat()
        if (commit) {
            animate().translationX(if (dx > 0) w else -w).setDuration(190)
                .setInterpolator(android.view.animation.DecelerateInterpolator(1.4f))
                .withEndAction { onSwipe(if (dx > 0) "r" else "l") }.start()
        } else {
            animate().translationX(0f).setDuration(240)
                .setInterpolator(android.view.animation.DecelerateInterpolator(1.8f)).start()
        }
    }

    override fun onTouchEvent(e: android.view.MotionEvent): Boolean {
        when (e.actionMasked) {
            android.view.MotionEvent.ACTION_MOVE -> {
                val dx = e.x - x0
                translationX = if (allowed(dx)) dx else dx * 0.2f
                val dt = Math.max(1L, e.eventTime - lastT)
                vx = (e.x - lastX) / dt
                lastX = e.x
                lastT = e.eventTime
            }
            android.view.MotionEvent.ACTION_UP -> {
                val dx = e.x - x0
                val fast = Math.abs(vx) > 0.5f && (vx > 0) == (dx > 0)
                settle(allowed(dx) && (Math.abs(dx) > width * 0.33f || fast), dx)
            }
            android.view.MotionEvent.ACTION_CANCEL -> settle(false, 0f)
        }
        return true
    }
}
