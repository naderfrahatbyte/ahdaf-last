package app.goals

import android.app.Activity
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import org.json.JSONObject

// نسخة احتياطية أسبوعية تلقائية في Download/Ahdaf (4 ملفات تتبدّل بالتناوب)، قابلة للاستيراد من الإعدادات
object AutoBackup {
    private val writeLock = Any()
    private const val WEEK = 7L * 24L * 3600L * 1000L

    fun lastTime(c: Context): Long = c.getSharedPreferences("backup", 0).getLong("last", 0L)

    private fun hasData(c: Context): Boolean {
        return try {
            val o = Store.data(c)
            (o.optJSONArray("goals")?.length() ?: 0) > 0 ||
                (o.optJSONArray("loose")?.length() ?: 0) > 0 ||
                (o.optJSONArray("lists")?.length() ?: 0) > 0 ||
                (o.optJSONArray("habits")?.length() ?: 0) > 0 ||
                FocusStore.habits.isNotEmpty() || FocusStore.earn.isNotEmpty() ||
                FocusStore.spend.isNotEmpty() || FocusStore.log.isNotEmpty()
        } catch (e: Exception) {
            false
        }
    }

    // تبني الملف على الخيط الحالي (سريع) وتكتبه في الخلفية، إلا إن طُلب التنفيذ المتزامن
    fun runIfDue(c: Context, sync: Boolean = false, force: Boolean = false): Boolean {
        try {
            val sp = c.getSharedPreferences("backup", 0)
            val now = System.currentTimeMillis()
            if (!force && now - sp.getLong("last", 0L) < WEEK) return false
            FocusStore.init(c)
            if (!hasData(c)) return false
            val full = JSONObject(Store.data(c).toString())
            full.put("focus", FocusStore.snapshot(c))
            full.put("savedAt", now)
            val bytes = full.toString().toByteArray(Charsets.UTF_8)
            val name = "ahdaf-auto-backup-" + (((now / WEEK) % 4L) + 1L) + ".json"
            val job = Runnable {
                synchronized(writeLock) {
                    try {
                        if (write(c, name, bytes)) sp.edit().putLong("last", now).commit()
                    } catch (_: Exception) {
                    }
                }
            }
            if (sync) job.run() else Thread(job).start()
            return true
        } catch (e: Exception) {
            return false
        }
    }

    private fun write(c: Context, name: String, bytes: ByteArray): Boolean {
        try {
            val parsed = JSONObject(String(bytes, Charsets.UTF_8))
            if (!parsed.has("goals") && !parsed.has("loose") && !parsed.has("lists") && !parsed.has("habits")) return false
        } catch (_: Exception) { return false }

        if (Build.VERSION.SDK_INT >= 29) {
            val cr = c.contentResolver
            val coll = MediaStore.Downloads.EXTERNAL_CONTENT_URI
            val tempName = ".$name.${System.currentTimeMillis()}.tmp"
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, tempName)
                put(MediaStore.MediaColumns.MIME_TYPE, "application/json")
                put(MediaStore.MediaColumns.RELATIVE_PATH, "Download/Ahdaf")
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val tempUri = cr.insert(coll, values) ?: return false
            try {
                val os = cr.openOutputStream(tempUri, "w") ?: return false
                os.use { it.write(bytes); it.flush() }
                val check = cr.openInputStream(tempUri)?.use { input -> input.readBytes() } ?: return false
                if (!check.contentEquals(bytes)) return false
                val old = ArrayList<Uri>()
                cr.query(coll, arrayOf(MediaStore.MediaColumns._ID),
                    MediaStore.MediaColumns.DISPLAY_NAME + "=? AND " + MediaStore.MediaColumns.RELATIVE_PATH + " LIKE ?",
                    arrayOf(name, "Download/Ahdaf%"), null)?.use { cur ->
                    while (cur.moveToNext()) old.add(ContentUris.withAppendedId(coll, cur.getLong(0)))
                }
                val publish = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                    put(MediaStore.MediaColumns.IS_PENDING, 0)
                }
                if (cr.update(tempUri, publish, null, null) <= 0) return false
                old.forEach { cr.delete(it, null, null) }
                return true
            } finally {
                try {
                    cr.query(tempUri, arrayOf(MediaStore.MediaColumns.DISPLAY_NAME), null, null, null)?.use { cur ->
                        if (cur.moveToFirst() && cur.getString(0) == tempName) cr.delete(tempUri, null, null)
                    }
                } catch (_: Exception) { }
            }
        }
        val dir = c.getExternalFilesDir(null) ?: return false
        if (!dir.exists() && !dir.mkdirs()) return false
        val target = java.io.File(dir, name)
        val temp = java.io.File(dir, ".$name.tmp")
        try {
            java.io.FileOutputStream(temp).use { stream ->
                stream.write(bytes); stream.flush(); stream.fd.sync()
            }
            if (!temp.readBytes().contentEquals(bytes)) return false
            if (!temp.renameTo(target)) {
                val old = java.io.File(dir, ".$name.old")
                if (target.exists() && !target.renameTo(old)) return false
                if (!temp.renameTo(target)) {
                    if (old.exists()) old.renameTo(target)
                    return false
                }
                old.delete()
            }
            return true
        } catch (_: Exception) {
            return false
        } finally {
            temp.delete()
        }
    }
}

// مسح كل البيانات (الأهداف والمهام والقوائم وFocus) مع الإبقاء على إعدادات الشكل واللغة
object DataReset {
    fun wipe(a: Activity) {
        DataSafe.snapshot(a, T("قبل مسح البيانات", "Before erase"))
        FocusStore.reset(a)
        a.getSharedPreferences("g", 0).edit().remove("d").apply()
        GoalsWidget.refresh(a)
        a.startActivity(Intent(a, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK))
        a.finish()
    }
}
