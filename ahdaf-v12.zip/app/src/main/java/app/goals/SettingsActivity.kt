package app.goals

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.Window
import android.widget.CompoundButton
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch

class SettingsActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Lang.load(this)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        val pal = PalGen.get(this, 85)
        fun dp(v: Int): Int = Ui.dp(this, v)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.layoutDirection = Lang.dir
        root.setPadding(dp(20), dp(18), dp(20), dp(16))
        root.addView(Ui.tv(this, T("الإعدادات", "Settings"), 20f, pal.fg, true))

        val lbl = Ui.tv(this, T("شفافية الودجت: ", "Widget transparency: ") + Store.tr(this) + "%", 15f, pal.fg)
        root.addView(lbl, Ui.lp(Ui.MP, Ui.WC, dp(16)))
        val bar = SeekBar(this)
        bar.max = 100
        bar.progress = Store.tr(this)
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                lbl.text = T("شفافية الودجت: ", "Widget transparency: ") + progress + "%"
                Store.setTr(this@SettingsActivity, progress)
                GoalsWidget.refresh(this@SettingsActivity)
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        root.addView(bar, Ui.lp(Ui.MP, Ui.WC))

        // حجم الخط: يُطبَّق على نصوص وأرقام الودجت
        val fsLbl = Ui.tv(this, "", 15f, pal.fg)
        root.addView(fsLbl, Ui.lp(Ui.MP, Ui.WC, dp(16)))
        val fsBar = SeekBar(this)
        fsBar.max = 50
        fsBar.progress = Store.fontScale(this) - 80
        root.addView(fsBar, Ui.lp(Ui.MP, Ui.WC))
        val pv = LinearLayout(this)
        pv.orientation = LinearLayout.VERTICAL
        pv.setPadding(dp(14), dp(10), dp(14), dp(10))
        pv.background = Ui.shape(PalGen.alpha(pal.fg, 18), 0, dp(14).toFloat())
        val pv1 = Ui.tv(this, T("مراجعة تقرير الأسبوع", "Review the weekly report"), 13f, pal.fg)
        val pv2 = Ui.tv(this, T("هدف القراءة · 12 أكتوبر", "Reading goal · 12 Oct"), 11f, pal.muted)
        pv.addView(pv1)
        pv.addView(pv2)
        root.addView(pv, Ui.lp(Ui.MP, Ui.WC, dp(8)))
        fun applyFs(v: Int) {
            val sc = v / 100f
            fsLbl.text = T("حجم الخط: ", "Font size: ") + v + "%"
            pv1.textSize = 13f * sc
            pv2.textSize = 11f * sc
        }
        applyFs(Store.fontScale(this))
        fsBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val v = 80 + progress
                applyFs(v)
                Store.setFontScale(this@SettingsActivity, v)
                GoalsWidget.refresh(this@SettingsActivity)
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        val fsReset = Ui.btn(this, T("استعادة الحجم الافتراضي", "Restore default size"), PalGen.alpha(pal.fg, 28), pal.fg)
        fsReset.setOnClickListener { fsBar.progress = 20 }
        root.addView(fsReset, Ui.lp(Ui.MP, Ui.WC, dp(8)))

        fun sw(t: String, key: String, after: (Boolean) -> Unit = {}) {
            val s = Switch(this)
            s.text = t
            s.textSize = 15f
            s.setTextColor(pal.fg)
            s.isChecked = Store.flag(this, key)
            s.setOnCheckedChangeListener { _: CompoundButton, on: Boolean ->
                Store.setFlag(this, key, on)
                after(on)
            }
            root.addView(s, Ui.lp(Ui.MP, Ui.WC, dp(14)))
        }
        sw(T("الأصوات", "Sounds"), "snd")
        sw(T("الاحتفالات المتحركة", "Celebration animations"), "anim")

        // ===== الإشعارات (مع باقي الإعدادات) =====
        root.addView(Ui.tv(this, T("الإشعارات", "Notifications"), 13f, pal.muted, true), Ui.lp(Ui.MP, Ui.WC, dp(22)))
        fun askNotifPerm() {
            if (android.os.Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED
            ) {
                try {
                    requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 5503)
                } catch (e: Exception) {
                }
            }
        }
        sw(T("تذكيرات المهام والعادات", "Task & habit reminders"), "rem") { on ->
            Reminders.reschedule(this)
            if (on) askNotifPerm()
        }
        sw(T("ملخص الصباح (مهام وعادات اليوم)", "Morning digest (today's tasks & habits)"), "dg") { on ->
            Reminders.reschedule(this)
            if (on) askNotifPerm()
        }
        val dgTime = Ui.btn(this, T("وقت الملخص: ", "Digest time: ") + Reminders.digestTime(this), PalGen.alpha(pal.fg, 28), pal.fg)
        dgTime.setOnClickListener {
            val cur = Reminders.digestTime(this).split(":")
            android.app.TimePickerDialog(this, { _, h, m ->
                Reminders.setDigestTime(this, String.format(java.util.Locale.US, "%02d:%02d", h, m))
                dgTime.text = T("وقت الملخص: ", "Digest time: ") + Reminders.digestTime(this)
                Reminders.reschedule(this)
            }, cur[0].toIntOrNull() ?: 8, cur.getOrNull(1)?.toIntOrNull() ?: 0, true).show()
        }
        root.addView(dgTime, Ui.lp(Ui.MP, Ui.WC, dp(8)))
        sw(T("تنبيهات Focus (توقف الخدمة ونفاد الرصيد)", "Focus alerts (service stopped, low credit)"), "fal")
        val enabled = (getSystemService(NOTIFICATION_SERVICE) as android.app.NotificationManager).areNotificationsEnabled()
        val perm = Ui.btn(
            this,
            if (enabled) T("إذن الإشعارات: مسموح ✓", "Notifications: allowed ✓") else T("الإشعارات غير مسموحة — اضغط للسماح", "Notifications are off — tap to allow"),
            PalGen.alpha(pal.fg, 28), if (enabled) pal.fg else pal.warn
        )
        perm.setOnClickListener {
            try {
                if (android.os.Build.VERSION.SDK_INT >= 26) {
                    startActivity(
                        android.content.Intent(android.provider.Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                            .putExtra(android.provider.Settings.EXTRA_APP_PACKAGE, packageName)
                    )
                }
            } catch (e: Exception) {
            }
        }
        root.addView(perm, Ui.lp(Ui.MP, Ui.WC, dp(8)))

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val ex = Ui.btn(this, T("نسخ احتياطي", "Back up"), PalGen.alpha(pal.fg, 28), pal.fg)
        val im = Ui.btn(this, T("استيراد", "Import"), PalGen.alpha(pal.fg, 28), pal.fg)
        ex.setOnClickListener { Backup.export(this) }
        im.setOnClickListener { Backup.importFile(this) }
        val l1 = LinearLayout.LayoutParams(0, Ui.WC, 1f)
        l1.setMargins(0, 0, dp(8), 0)
        row.addView(ex, l1)
        row.addView(im, LinearLayout.LayoutParams(0, Ui.WC, 1f))
        root.addView(row, Ui.lp(Ui.MP, Ui.WC, dp(18)))

        // نسخة احتياطية تلقائية أسبوعية + مسح كل البيانات
        val last = AutoBackup.lastTime(this)
        val lastTxt = if (last > 0L) java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date(last)) else T("لم تُنشأ بعد", "not yet")
        val autoV = Ui.tv(this, T("نسخة احتياطية تلقائية كل أسبوع في Download/Ahdaf. آخر نسخة: ", "Automatic weekly backup in Download/Ahdaf. Last: ") + lastTxt + T(" — اضغط لعمل نسخة الآن.", " — tap to back up now."), 12f, pal.muted)
        autoV.setOnClickListener {
            val before = AutoBackup.lastTime(this)
            AutoBackup.runIfDue(this, true, true)
            val done = AutoBackup.lastTime(this) > before
            android.widget.Toast.makeText(this, if (done) T("تم حفظ النسخة", "Backup saved") else T("تعذّر الحفظ أو لا توجد بيانات", "Could not save, or no data"), android.widget.Toast.LENGTH_SHORT).show()
        }
        root.addView(autoV, Ui.lp(Ui.MP, Ui.WC, dp(10)))
        val wipe = Ui.btn(this, T("مسح كل البيانات", "Erase all data"), Color.TRANSPARENT, pal.warn)
        wipe.setOnClickListener {
            android.app.AlertDialog.Builder(this)
                .setTitle(T("مسح كل البيانات؟", "Erase all data?"))
                .setMessage(T("سيتم حذف كل الأهداف والمهام والقوائم وبيانات Focus نهائيًا. يُنصح بعمل نسخة احتياطية أولًا.", "All goals, tasks, lists and Focus data will be permanently deleted. Back up first if you may need them."))
                .setPositiveButton(T("مسح", "Erase")) { _, _ -> DataReset.wipe(this) }
                .setNegativeButton(T("إلغاء", "Cancel"), null)
                .show()
        }
        root.addView(wipe, Ui.lp(Ui.MP, Ui.WC, dp(6)))

        val ok = Ui.btn(this, T("تم", "Done"), pal.accent, if (pal.dark) Color.parseColor("#0B1020") else Color.WHITE)
        ok.setOnClickListener { finish() }
        root.addView(ok, Ui.lp(Ui.MP, Ui.WC, dp(12)))

        val sv = ScrollView(this)
        sv.addView(root)
        setContentView(sv)
        Glass.apply(this, pal)
        window.setGravity(Gravity.BOTTOM)
        window.setDimAmount(0f)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        Backup.result(this, requestCode, resultCode, data)
    }
}
