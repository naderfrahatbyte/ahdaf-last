package app.goals

import android.content.Context
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter

// يحفظ آخر عطل في ملف ليمكن نسخه من الإعدادات وإرساله لإصلاح السبب
object CrashLog {
    private fun file(c: Context) = File(c.filesDir, "crash.txt")

    @Suppress("DEPRECATION")
    private fun version(c: Context): String = try {
        c.packageManager.getPackageInfo(c.packageName, 0).versionName ?: "?"
    } catch (e: Exception) {
        "?"
    }

    fun install(c: Context) {
        val app = c.applicationContext
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                val sw = StringWriter()
                e.printStackTrace(PrintWriter(sw))
                val head = "version " + version(app) + " | " + java.util.Date() + " | thread " + t.name + "\n"
                file(app).writeText((head + sw.toString()).take(6000), Charsets.UTF_8)
            } catch (x: Throwable) {
            }
            if (prev != null) prev.uncaughtException(t, e)
        }
    }

    private var lastAppend = 0L

    // أخطاء الواجهة (JavaScript): تُسجَّل في نفس الملف دون إزعاج بإشعار
    fun append(c: Context, msg: String) {
        try {
            val now = System.currentTimeMillis()
            if (now - lastAppend < 300L) return
            lastAppend = now
            val f = file(c)
            val old = if (f.exists()) f.readText(Charsets.UTF_8) else ""
            val line = "[" + java.util.Date() + " v" + version(c) + "] " + msg.take(1500) + "\n"
            f.writeText((old + line).takeLast(6000), Charsets.UTF_8)
            c.getSharedPreferences("safe", 0).edit().putLong("crash_seen", f.lastModified()).apply()
        } catch (e: Exception) {
        }
    }

    fun read(c: Context): String = try {
        val f = file(c)
        if (f.exists()) f.readText(Charsets.UTF_8) else ""
    } catch (e: Exception) {
        ""
    }

    fun clear(c: Context) {
        try {
            file(c).delete()
        } catch (e: Exception) {
        }
    }

    // true مرة واحدة لكل عطل جديد، لنخبر المستخدم أن هناك تقريرًا
    fun takeNotice(c: Context): Boolean {
        val f = file(c)
        if (!f.exists()) return false
        val sp = c.getSharedPreferences("safe", 0)
        val m = f.lastModified()
        if (sp.getLong("crash_seen", 0L) == m) return false
        sp.edit().putLong("crash_seen", m).apply()
        return true
    }

    fun versionName(c: Context): String = version(c)
}
