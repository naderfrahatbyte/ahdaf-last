package app.goals

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

// حدث تذكير واحد: key فريد يمنع تكراره
class Ev(
    val at: Long, val key: String, val kind: String, val id: String,
    val title: String, val body: String, val tab: String, val mkey: String, val nid: Int
)

// تذكيرات المهام (rt على المهمة) والعادات (rt على العادة) + ملخص الصباح. تنبيه واحد قادم فقط يُجدوَل ثم يُعاد الحساب
object Reminders {
    private const val CH = "reminders"
    private const val LATE = 3L * 3600L * 1000L
    private const val SOON = 20000L

    fun digestOn(c: Context): Boolean = Store.flag(c, "dg")
    fun digestTime(c: Context): String = c.getSharedPreferences("g", 0).getString("dg_t", "08:00") ?: "08:00"
    fun setDigestTime(c: Context, v: String) {
        c.getSharedPreferences("g", 0).edit().putString("dg_t", v).apply()
    }

    private fun atMillis(day: Int, hhmm: String): Long {
        val p = hhmm.split(":")
        val h = p.getOrNull(0)?.toIntOrNull() ?: return -1L
        val m = p.getOrNull(1)?.toIntOrNull() ?: 0
        val cv = civil(day)
        val cal = Calendar.getInstance()
        cal.clear()
        cal.set(cv[0], cv[1] - 1, cv[2], h.coerceIn(0, 23), m.coerceIn(0, 59), 0)
        return cal.timeInMillis
    }

    fun events(c: Context): List<Ev> {
        val out = ArrayList<Ev>()
        val o = Store.data(c)
        val today = todayDay()

        fun addTask(t: JSONObject, mkey: String) {
            val rt = t.optString("rt")
            val ds = t.optString("date")
            if (rt.isBlank() || ds.isBlank() || t.optBoolean("done")) return
            val at = atMillis(days(ds), rt)
            if (at < 0L) return
            val desc = t.optString("desc")
            out.add(
                Ev(
                    at, "t|" + mkey + "|" + ds + "|" + rt, "task", mkey, t.optString("title"),
                    if (desc.isBlank()) T("موعد مهمتك الآن", "Your task is due now") else desc,
                    "tasks", mkey, ("t|" + mkey + ds + rt).hashCode()
                )
            )
        }
        val goals = o.optJSONArray("goals")
        if (goals != null) {
            for (i in 0 until goals.length()) {
                val g = goals.optJSONObject(i) ?: continue
                val ts = g.optJSONArray("tasks") ?: continue
                for (j in 0 until ts.length()) {
                    val t = ts.optJSONObject(j) ?: continue
                    addTask(t, "g|" + g.optString("id") + "|" + t.optString("id"))
                }
            }
        }
        val loose = o.optJSONArray("loose")
        if (loose != null) {
            for (i in 0 until loose.length()) {
                val t = loose.optJSONObject(i) ?: continue
                addTask(t, "l|" + t.optString("id"))
            }
        }

        val ha = o.optJSONArray("habits")
        if (ha != null) {
            for (i in 0 until ha.length()) {
                val h = ha.optJSONObject(i) ?: continue
                val rt = h.optString("rt")
                if (rt.isBlank()) continue
                val id = h.optString("id")
                val cue = h.optString("cu").trim()
                val mn = h.optString("mn").trim()
                val parts = ArrayList<String>()
                if (cue.isNotEmpty()) parts.add(cue)
                if (mn.isNotEmpty()) parts.add(T("على الأقل ", "At least ") + mn)
                val body = if (parts.isEmpty()) T("حان وقت عادتك", "Time for your habit") else parts.joinToString(" · ")
                for (d in today..today + 13) {
                    if (!HabitsData.dueOn(h, d) || HabitsData.doneOn(h, d)) continue
                    val at = atMillis(d, rt)
                    if (at < 0L) continue
                    out.add(Ev(at, "h|" + id + "|" + HabitsData.isoOf(d) + "|" + rt, "habit", id, h.optString("t"), body, "habits", id, ("h|" + id + d + rt).hashCode()))
                }
            }
        }

        if (digestOn(c)) {
            val t = digestTime(c)
            for (d in today..today + 13) {
                val at = atMillis(d, t)
                if (at < 0L) continue
                out.add(Ev(at, "dg|" + HabitsData.isoOf(d) + "|" + t, "digest", "", "", "", "tasks", "", ("dg|" + d).hashCode()))
            }
        }
        out.sortBy { it.at }
        return out
    }

    private fun loadFired(c: Context, now: Long): HashMap<String, Long> {
        val sp = c.getSharedPreferences("rem", 0)
        val raw = sp.getStringSet("fired", emptySet()) ?: emptySet()
        val m = HashMap<String, Long>()
        for (e in raw) {
            val i = e.indexOf('|')
            if (i < 0) continue
            val ts = e.substring(0, i).toLongOrNull() ?: continue
            if (now - ts < 3L * 86400000L) m[e.substring(i + 1)] = ts
        }
        return m
    }

    private fun saveFired(c: Context, m: Map<String, Long>) {
        val set = HashSet<String>()
        for ((k, v) in m) set.add(v.toString() + "|" + k)
        c.getSharedPreferences("rem", 0).edit().putStringSet("fired", set).apply()
    }

    // عند ميعاد التنبيه: يُطلق ما حان وقته ثم يجدول الأقرب
    fun run(c: Context) {
        try {
            val now = System.currentTimeMillis()
            val fired = loadFired(c, now)
            val evs = events(c)
            for (e in evs) {
                if (fired.containsKey(e.key)) continue
                if (e.at <= now + SOON && e.at >= now - LATE) {
                    fired[e.key] = now
                    show(c, e)
                }
            }
            saveFired(c, fired)
            scheduleNext(c, evs, fired, now)
        } catch (e: Throwable) {
        }
    }

    // عند تغيّر البيانات أو فتح التطبيق: لا يُطلق شيئًا، يتجاهل ما فات، ويجدول الأقرب
    fun reschedule(c: Context) {
        try {
            val now = System.currentTimeMillis()
            val fired = loadFired(c, now)
            val evs = events(c)
            for (e in evs) if (e.at <= now + SOON && !fired.containsKey(e.key)) fired[e.key] = now
            saveFired(c, fired)
            scheduleNext(c, evs, fired, now)
        } catch (e: Throwable) {
        }
    }

    private fun scheduleNext(c: Context, evs: List<Ev>, fired: Map<String, Long>, now: Long) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = PendingIntent.getBroadcast(
            c, 91, Intent(c, ReminderReceiver::class.java).setAction("app.goals.REMIND"),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val next = evs.firstOrNull { it.at > now + SOON && !fired.containsKey(it.key) }
        if (next == null) {
            am.cancel(pi)
            return
        }
        try {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next.at, pi)
        } catch (e: Exception) {
            am.set(AlarmManager.RTC_WAKEUP, next.at, pi)
        }
    }

    // ملخص الصباح: مهام اليوم غير المنجزة + العادات المستحقة
    private fun digest(c: Context): Pair<String, String>? {
        val o = Store.data(c)
        val today = HabitsData.isoOf(todayDay())
        val names = ArrayList<String>()
        var tasks = 0
        fun scan(arr: JSONArray?) {
            if (arr == null) return
            for (i in 0 until arr.length()) {
                val t = arr.optJSONObject(i) ?: continue
                if (t.optString("date") == today && !t.optBoolean("done")) {
                    tasks++
                    if (names.size < 5) names.add("• " + t.optString("title"))
                }
            }
        }
        scan(o.optJSONArray("loose"))
        val goals = o.optJSONArray("goals")
        if (goals != null) for (i in 0 until goals.length()) scan(goals.optJSONObject(i)?.optJSONArray("tasks"))
        val habits = HabitsData.all(c).filter { it.due && !it.done }
        for (h in habits) if (names.size < 8) names.add("◦ " + h.title)
        if (tasks == 0 && habits.isEmpty()) return null
        val summary = T("اليوم: ", "Today: ") + tasks + T(" مهام", " tasks") + " · " + habits.size + T(" عادات", " habits")
        return Pair(summary, names.joinToString("\n"))
    }

    private fun show(c: Context, e: Ev) {
        try {
            val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= 26) {
                nm.createNotificationChannel(NotificationChannel(CH, T("التذكيرات", "Reminders"), NotificationManager.IMPORTANCE_DEFAULT))
            }
            val b: Notification.Builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(c, CH) else Notification.Builder(c)
            var title = e.title
            var text = e.body
            var big: String? = null
            if (e.kind == "digest") {
                val d = digest(c) ?: return
                title = T("صباح الخير 🌤", "Good morning 🌤")
                text = d.first
                big = d.second
            }
            val open = Intent(c, MainActivity::class.java)
            open.putExtra("tab", e.tab)
            open.data = Uri.parse("remind://open/" + e.nid)
            open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            b.setSmallIcon(R.mipmap.ic_launcher).setContentTitle(title).setContentText(text).setAutoCancel(true)
                .setCategory(Notification.CATEGORY_REMINDER)
                .setContentIntent(PendingIntent.getActivity(c, e.nid + 1, open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
            if (big != null) b.setStyle(Notification.BigTextStyle().bigText(big))
            if (e.kind == "task" || e.kind == "habit") {
                // زر «تم»: يُنجز عبر شاشة الاحتفال الشفافة (once = لا يُلغي إنجازًا حدث بالفعل)
                val done = Intent(c, CelebrateActivity::class.java)
                if (e.kind == "habit") done.putExtra("ht", e.mkey) else done.putExtra("m", e.mkey)
                done.putExtra("once", true).putExtra("nid", e.nid)
                done.data = Uri.parse("remind://done/" + Uri.encode(e.key))
                done.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
                b.addAction(0, T("تم ✓", "Done ✓"), PendingIntent.getActivity(c, e.nid, done, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
            }
            nm.notify(e.nid, b.build())
        } catch (ex: Exception) {
        }
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent?) {
        try {
            Reminders.run(c)
        } catch (e: Throwable) {
        }
    }
}
