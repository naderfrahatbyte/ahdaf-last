package app.goals

import android.animation.ValueAnimator
import android.app.Activity
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.media.MediaPlayer
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.TextView
import android.view.WindowManager

class CelebrateActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE)
        val key = intent.getStringExtra("m") ?: ""
        val parts = key.split("|")
        val gid = if (parts[0] == "g" && parts.size > 1) parts[1] else ""
        val before = Model(this)
        val g0 = before.byId[gid]
        val p0 = if (g0 != null) before.prog(g0) else 0f
        val par0 = if (g0 != null) before.byId[g0.parent] else null
        val pp0 = if (par0 != null) before.prog(par0) else 0f

        val done = Store.toggle(this, key)
        val rw = Store.lastReward
        GoalsWidget.refresh(this)
        val snd = Store.flag(this, "snd")
        val anim = Store.flag(this, "anim")
        if (!done || (!snd && !anim && rw <= 0.0)) {
            finish()
            overridePendingTransition(0, 0)
            return
        }
        val after = Model(this)
        val g1 = after.byId[gid]
        val goalDone = g1 != null && after.prog(g1) >= 0.999f && p0 < 0.999f
        val par1 = if (g1 != null) after.byId[g1.parent] else null
        val parDone = par1 != null && after.prog(par1) >= 0.999f && pp0 < 0.999f
        val level = if (goalDone || parDone) 2 else 1

        if (snd) play(if (level == 2) R.raw.goal_done else R.raw.task_done)
        buzz(level)
        if (anim || rw > 0.0) {
            val fl = FrameLayout(this)
            if (anim) fl.addView(Burst(this, level, PalGen.get(this, Store.tr(this)).tones))
            if (rw > 0.0) fl.addView(rewardText(rw), FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.CENTER))
            setContentView(fl)
        }
        val dur = if (level == 2) 2700L else (if (anim || rw > 0.0) 1500L else 500L)
        Handler(Looper.getMainLooper()).postDelayed({
            finish()
            overridePendingTransition(0, 0)
        }, dur)
    }

    // «+5»: مكافأة Focus تظهر وتطفو للأعلى مع الاحتفال
    private fun rewardText(rw: Double): TextView {
        val tv = TextView(this)
        tv.text = "+" + FocusStore.fmt(rw)
        tv.textSize = 46f
        tv.setTypeface(tv.typeface, Typeface.BOLD)
        tv.setTextColor(Color.parseColor("#F6D68C"))
        tv.setShadowLayer(18f, 0f, 2f, Color.parseColor("#99E8B84F"))
        tv.alpha = 0f
        tv.scaleX = 0.6f
        tv.scaleY = 0.6f
        val d = resources.displayMetrics.density
        tv.animate().alpha(1f).scaleX(1.15f).scaleY(1.15f).setDuration(260).withEndAction {
            tv.animate().translationY(-90f * d).alpha(0f).scaleX(1f).scaleY(1f).setDuration(1000).start()
        }.start()
        return tv
    }

    private fun play(res: Int) {
        try {
            val mp = MediaPlayer.create(this, res)
            player = mp
            mp.setOnCompletionListener { it.release() }
            mp.start()
        } catch (e: Exception) {
        }
    }

    private fun buzz(level: Int) {
        try {
            val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            if (Build.VERSION.SDK_INT >= 26) {
                if (level == 2) v.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 30, 70, 30, 70, 80), -1))
                else v.vibrate(VibrationEffect.createOneShot(25, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                v.vibrate(if (level == 2) 120L else 25L)
            }
        } catch (e: Exception) {
        }
    }

    companion object {
        var player: MediaPlayer? = null
    }
}

private class Burst(c: Context, private val level: Int, private val colors: IntArray) : View(c) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var t = 0f
    private val n = if (level == 2) 120 else 18
    private val ax = FloatArray(n)
    private val ay = FloatArray(n)
    private val sz = FloatArray(n)
    private val rot = FloatArray(n)

    init {
        val rnd = java.util.Random(7)
        for (i in 0 until n) {
            if (level == 2) {
                ax[i] = rnd.nextFloat()
                ay[i] = 0.5f + rnd.nextFloat() * 0.9f
            } else {
                val a = i * 2 * Math.PI / n
                ax[i] = Math.cos(a).toFloat()
                ay[i] = Math.sin(a).toFloat()
            }
            sz[i] = 0.6f + rnd.nextFloat() * 0.8f
            rot[i] = rnd.nextFloat() * 360f
        }
        val an = ValueAnimator.ofFloat(0f, 1f)
        an.duration = if (level == 2) 2600L else 1000L
        an.addUpdateListener {
            t = it.animatedValue as Float
            invalidate()
        }
        an.start()
    }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val d = resources.displayMetrics.density
        val cx = w / 2
        val cy = h * 0.55f
        val fade = (1f - t).coerceIn(0f, 1f)
        if (level == 1) {
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 3 * d
            paint.color = colors[0]
            paint.alpha = (255 * fade).toInt()
            cv.drawCircle(cx, cy, (30 + t * 110) * d, paint)
            paint.style = Paint.Style.FILL
            for (i in 0 until n) {
                paint.color = colors[i % colors.size]
                paint.alpha = (255 * fade).toInt()
                val r = (24 + t * 130 * sz[i]) * d
                cv.drawCircle(cx + ax[i] * r, cy + ay[i] * r, 4.5f * d * sz[i] * (1f - t * 0.6f), paint)
            }
        } else {
            val pulse = Math.sin(Math.PI * t).toFloat()
            val gr = (120 + 220 * t) * d
            paint.style = Paint.Style.FILL
            paint.shader = RadialGradient(cx, cy, gr, PalGen.alpha(colors[0], (150 * pulse).toInt()), Color.TRANSPARENT, Shader.TileMode.CLAMP)
            cv.drawCircle(cx, cy, gr, paint)
            paint.shader = null
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 3 * d
            paint.strokeCap = Paint.Cap.ROUND
            for (k in 0 until 12) {
                val a = k * Math.PI / 6
                val r0 = (40 + t * 80) * d
                val r1 = r0 + (30 + 60 * pulse) * d
                paint.color = colors[k % colors.size]
                paint.alpha = (255 * fade).toInt()
                cv.drawLine(cx + (Math.cos(a) * r0).toFloat(), cy + (Math.sin(a) * r0).toFloat(), cx + (Math.cos(a) * r1).toFloat(), cy + (Math.sin(a) * r1).toFloat(), paint)
            }
            paint.style = Paint.Style.FILL
            for (i in 0 until n) {
                val x = ax[i] * w + Math.sin((t * 6 + i).toDouble()).toFloat() * 20 * d
                val y = -30 * d + t * h * ay[i] * 1.1f
                paint.color = colors[i % colors.size]
                paint.alpha = (255 * (if (t > 0.75f) (1f - t) * 4f else 1f)).toInt().coerceIn(0, 255)
                cv.save()
                cv.rotate(rot[i] + t * 540f, x, y)
                cv.drawRect(x - 4 * d * sz[i], y - 7 * d * sz[i], x + 4 * d * sz[i], y + 7 * d * sz[i], paint)
                cv.restore()
            }
        }
    }
}
