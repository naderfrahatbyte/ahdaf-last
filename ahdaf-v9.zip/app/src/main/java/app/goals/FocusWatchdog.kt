package app.goals

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock

// حارس Focus: يستيقظ كل ~15 دقيقة، ينبّه إن توقفت المراقبة، ويجري النسخة الاحتياطية الأسبوعية
class FocusWatchdog : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent?) {
        try {
            if (i?.action == Intent.ACTION_BOOT_COMPLETED) {
                schedule(c)
                return
            }
            FocusStore.init(c)
            AutoBackup.runIfDue(c, true)
            val inUse = FocusStore.spend.isNotEmpty() || FocusStore.earn.isNotEmpty()
            if (!inUse) {
                cancel(c)
                return
            }
            if (!FocusService.enabled(c)) {
                alertDown(c)
                return
            }
            val pm = c.getSystemService(Context.POWER_SERVICE) as PowerManager
            if (pm.isInteractive) {
                if (down()) {
                    // نعيد الفحص بعد ثوانٍ: قد يكون الجهاز استيقظ للتو والخدمة لم تُحدّث نبضها بعد
                    val pr = goAsync()
                    Handler(Looper.getMainLooper()).postDelayed({
                        try {
                            if (down()) alertDown(c) else cancel(c)
                        } catch (e: Throwable) {
                        } finally {
                            pr.finish()
                        }
                    }, 6000)
                } else cancel(c)
            }
        } catch (e: Throwable) {
        }
    }

    private fun down(): Boolean = FocusStore.hb == 0L || SystemClock.elapsedRealtime() - FocusStore.hb > 20000L

    companion object {
        const val ID_LOW = 735
        private const val ID_DOWN = 736

        fun schedule(c: Context) {
            try {
                val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
                val wi = Intent(c, FocusWatchdog::class.java).setAction("app.goals.WATCHDOG")
                // مجدول بالفعل؟ لا نعيد ضبط المؤقّت مع كل فتح للتطبيق حتى لا يتأجل للأبد
                if (PendingIntent.getBroadcast(c, 0, wi, PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE) != null) return
                val pi = PendingIntent.getBroadcast(c, 0, wi, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                am.setInexactRepeating(
                    AlarmManager.ELAPSED_REALTIME,
                    SystemClock.elapsedRealtime() + AlarmManager.INTERVAL_FIFTEEN_MINUTES,
                    AlarmManager.INTERVAL_FIFTEEN_MINUTES, pi
                )
            } catch (e: Exception) {
            }
        }

        private fun nm(c: Context): NotificationManager = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        private fun cancel(c: Context) {
            try {
                nm(c).cancel(ID_DOWN)
            } catch (e: Exception) {
            }
        }

        private fun alertDown(c: Context) {
            post(
                c, ID_DOWN, T("Focus متوقف", "Focus has stopped"),
                T("اضغط لإصلاحه حتى يستمر احتساب الرصيد والحظر.", "Tap to fix it so credit and blocking keep working."), false
            )
        }

        fun post(c: Context, id: Int, title: String, text: String, autoHide: Boolean) {
            try {
                val manager = nm(c)
                val open = PendingIntent.getActivity(
                    c, id, Intent(c, FocusActivity::class.java).putExtra("from", "notification"),
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                val builder: Notification.Builder
                if (Build.VERSION.SDK_INT >= 26) {
                    manager.createNotificationChannel(NotificationChannel("focus_alert", T("تنبيهات Focus", "Focus alerts"), NotificationManager.IMPORTANCE_DEFAULT))
                    builder = Notification.Builder(c, "focus_alert")
                } else {
                    builder = Notification.Builder(c)
                }
                builder.setSmallIcon(R.mipmap.ic_launcher).setContentTitle(title).setContentText(text).setContentIntent(open).setAutoCancel(true)
                if (autoHide && Build.VERSION.SDK_INT >= 26) builder.setTimeoutAfter(60000L)
                manager.notify(id, builder.build())
            } catch (e: Exception) {
            }
        }
    }
}
