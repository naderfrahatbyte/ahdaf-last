package app.goals

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.net.Uri
import android.text.TextPaint
import android.text.TextUtils
import android.widget.RemoteViews

// ودجت 1×1: مربع للعادات. عادة واحدة أو عدة عادات خلف بعضها؛ لمس الدائرة = إنجاز اليوم، ولمس أسفل المربع = العادة التالية
class HabitWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) {
        for (id in ids) update(c, m, id)
    }

    override fun onAppWidgetOptionsChanged(c: Context, m: AppWidgetManager, id: Int, newOptions: android.os.Bundle) {
        update(c, m, id)
    }

    override fun onDeleted(c: Context, ids: IntArray) {
        val e = c.getSharedPreferences("hw", 0).edit()
        for (id in ids) {
            e.remove("w" + id)
            e.remove("i" + id)
        }
        e.apply()
    }

    override fun onReceive(c: Context, i: Intent) {
        super.onReceive(c, i)
        val id = i.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, -1)
        if (id < 0) return
        when (i.action) {
            ACT_NEXT -> {
                val sp = c.getSharedPreferences("hw", 0)
                sp.edit().putInt("i" + id, sp.getInt("i" + id, 0) + 1).apply()
                update(c, AppWidgetManager.getInstance(c), id)
            }
            ACT_TOGGLE -> {
                val list = habitsFor(c, id)
                if (list.isNotEmpty()) {
                    val idx = c.getSharedPreferences("hw", 0).getInt("i" + id, 0)
                    val h = list[Math.floorMod(idx, list.size)]
                    HabitsData.toggleToday(c, h.id)
                    GoalsWidget.refresh(c)
                    refreshAll(c)
                    MainActivity.notifyDataChanged()
                    MainActivity.notifyFocusChanged()
                }
            }
        }
    }

    companion object {
        const val ACT_NEXT = "app.goals.HW_NEXT"
        const val ACT_TOGGLE = "app.goals.HW_TOGGLE"

        fun refreshAll(c: Context) {
            val m = AppWidgetManager.getInstance(c)
            for (id in m.getAppWidgetIds(ComponentName(c, HabitWidget::class.java))) update(c, m, id)
        }

        fun saveSelection(c: Context, id: Int, ids: List<String>) {
            c.getSharedPreferences("hw", 0).edit().putString("w" + id, ids.joinToString(",")).putInt("i" + id, 0).apply()
        }

        // بدون اختيار = كل العادات
        fun habitsFor(c: Context, id: Int): List<HabitInfo> {
            val all = HabitsData.all(c)
            val sel = (c.getSharedPreferences("hw", 0).getString("w" + id, "") ?: "").split(",").filter { it.isNotBlank() }
            if (sel.isEmpty()) return all
            return sel.mapNotNull { s -> all.firstOrNull { it.id == s } }
        }

        private fun pi(c: Context, action: String, id: Int): PendingIntent {
            val i = Intent(c, HabitWidget::class.java)
            i.action = action
            i.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
            i.data = Uri.parse("habitw://" + action + "/" + id)
            return PendingIntent.getBroadcast(c, id, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        }

        // لمس الدائرة: يفتح شاشة الاحتفال الشفافة التي تبدّل الإنجاز وتعرض التأثير
        private fun toggleIntent(c: Context, id: Int, habitId: String): PendingIntent {
            val i = Intent(c, CelebrateActivity::class.java)
            i.putExtra("ht", habitId)
            i.data = Uri.parse("habitw://toggle/" + id + "/" + Uri.encode(habitId))
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
            return PendingIntent.getActivity(c, id + 7000, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        }

        private fun openHabits(c: Context): PendingIntent {
            val i = Intent(c, MainActivity::class.java)
            i.putExtra("tab", "habits")
            i.data = Uri.parse("habitw://open")
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            return PendingIntent.getActivity(c, 0, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        }

        fun update(c: Context, mgr: AppWidgetManager, id: Int) {
            Lang.load(c)
            val list = habitsFor(c, id)
            val sp = c.getSharedPreferences("hw", 0)
            val idx = if (list.isEmpty()) 0 else Math.floorMod(sp.getInt("i" + id, 0), list.size)
            // نرسم الصورة بمقاس الخلية الفعلي (أيقونة + اسمها) لتملأها بدل مربع صغير في وسطها
            val o = mgr.getAppWidgetOptions(id)
            val d = c.resources.displayMetrics.density
            val wDp = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 74).coerceIn(40, 220)
            val hDp = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 96).coerceIn(40, 260)
            val rv = RemoteViews(c.packageName, R.layout.habit_widget)
            rv.setImageViewBitmap(R.id.hw_img, draw(c, list, idx, (wDp * d).toInt(), (hDp * d).toInt(), d))
            if (list.isEmpty()) {
                rv.setOnClickPendingIntent(R.id.hw_top, openHabits(c))
                rv.setOnClickPendingIntent(R.id.hw_bottom, openHabits(c))
            } else {
                val tg = toggleIntent(c, id, list[idx].id)
                rv.setOnClickPendingIntent(R.id.hw_top, tg)
                rv.setOnClickPendingIntent(R.id.hw_bottom, if (list.size > 1) pi(c, ACT_NEXT, id) else tg)
            }
            mgr.updateAppWidget(id, rv)
        }

        private fun draw(c: Context, list: List<HabitInfo>, idx: Int, w: Int, h: Int, d: Float): Bitmap {
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val cv = Canvas(bmp)
            // نفس فلسفة ودجت الأسبوع: خلفية سوداء شفافة بدرجة شفافية الإعدادات، وألوان مأخوذة من خلفية الشاشة
            val tr = Store.tr(c)
            val pal = PalGen.get(c, tr)
            val scrimA = ((100 - tr) * 0.8f * 2.55f).toInt().coerceIn(0, 255)
            val fg = pal.fg
            val muted = pal.muted
            val accent = pal.accent
            val faint = PalGen.alpha(pal.fg, 45)
            val onAccent = if (pal.dark) Color.parseColor("#15101d") else Color.WHITE
            val p = Paint(Paint.ANTI_ALIAS_FLAG)
            p.style = Paint.Style.FILL
            p.color = Color.argb(scrimA, 0, 0, 0)
            cv.drawRoundRect(RectF(0f, 0f, w.toFloat(), h.toFloat()), 22f * d, 22f * d, p)

            val tp = TextPaint(Paint.ANTI_ALIAS_FLAG)
            tp.textAlign = Paint.Align.CENTER
            if (list.isEmpty()) {
                tp.color = muted
                tp.textSize = 12f * d
                tp.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                val t = TextUtils.ellipsize(T("أضف عادة", "Add a habit"), tp, w - 16f * d, TextUtils.TruncateAt.END).toString()
                cv.drawText(t, w / 2f, h / 2f + 4f * d, tp)
                return bmp
            }
            val hb = list[idx]
            val cx = w / 2f
            val cy = h * 0.31f
            val r = Math.min(w * 0.2f, h * 0.15f)
            p.strokeCap = Paint.Cap.ROUND
            p.strokeJoin = Paint.Join.ROUND
            if (hb.done) {
                p.style = Paint.Style.FILL
                p.color = accent
                cv.drawCircle(cx, cy, r, p)
                p.style = Paint.Style.STROKE
                p.strokeWidth = Math.max(2.5f * d, r * 0.17f)
                p.color = onAccent
                val k = r / 44f
                val chk = Path()
                chk.moveTo(cx - 17f * k, cy + 2f * k)
                chk.lineTo(cx - 5f * k, cy + 14f * k)
                chk.lineTo(cx + 19f * k, cy - 13f * k)
                cv.drawPath(chk, p)
            } else {
                p.style = Paint.Style.STROKE
                p.strokeWidth = Math.max(2.5f * d, r * 0.17f)
                p.color = if (hb.due) accent else faint
                cv.drawCircle(cx, cy, r - p.strokeWidth / 2f, p)
                if (hb.streak > 0) {
                    tp.color = if (hb.due) accent else muted
                    tp.textSize = r * 1.0f
                    tp.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
                    cv.drawText(hb.streak.toString(), cx, cy + r * 0.34f, tp)
                }
            }
            tp.color = if (hb.due) fg else muted
            tp.textSize = 12.5f * d
            tp.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            val title = TextUtils.ellipsize(hb.title, tp, w - 14f * d, TextUtils.TruncateAt.END).toString()
            cv.drawText(title, cx, h * 0.665f, tp)

            // صف النقاط: مؤشّر العادات إن كانت أكثر من واحدة، وإلا آخر 7 أيام للعادة
            val n = if (list.size > 1) Math.min(list.size, 7) else 7
            val gap = Math.min(9f * d, w * 0.8f / 6f)
            val x0 = cx - gap * (n - 1) / 2f
            val y = h * 0.855f
            val dr = 2.8f * d
            for (k in 0 until n) {
                val x = x0 + gap * k
                if (list.size > 1) {
                    val cur = k == Math.min(idx, 6)
                    p.style = Paint.Style.FILL
                    p.color = if (cur) accent else faint
                    cv.drawCircle(x, y, if (cur) dr * 1.25f else dr * 0.9f, p)
                } else {
                    when (hb.week[k]) {
                        1 -> {
                            p.style = Paint.Style.FILL
                            p.color = accent
                            cv.drawCircle(x, y, dr, p)
                        }
                        2 -> {
                            p.style = Paint.Style.STROKE
                            p.strokeWidth = 1.2f * d
                            p.color = PalGen.alpha(pal.fg, 110)
                            cv.drawCircle(x, y, dr * 0.85f, p)
                        }
                        3 -> {
                            p.style = Paint.Style.STROKE
                            p.strokeWidth = 1.4f * d
                            p.color = accent
                            cv.drawCircle(x, y, dr * 0.9f, p)
                        }
                        else -> {
                            p.style = Paint.Style.FILL
                            p.color = PalGen.alpha(pal.fg, 40)
                            cv.drawCircle(x, y, dr * 0.55f, p)
                        }
                    }
                }
            }
            return bmp
        }
    }
}
