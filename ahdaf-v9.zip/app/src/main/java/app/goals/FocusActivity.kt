package app.goals

import android.app.Activity
import android.content.Intent
import android.os.Bundle

// Focus صار تبويبًا داخل التطبيق؛ هذه الشاشة تحوّل الإشعارات والاختصارات القديمة إليه
class FocusActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        startActivity(
            Intent(this, MainActivity::class.java)
                .putExtra("tab", "focus")
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        )
        finish()
    }
}
