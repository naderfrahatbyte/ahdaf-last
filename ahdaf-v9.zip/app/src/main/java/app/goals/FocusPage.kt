package app.goals

import android.app.Activity
import android.app.Dialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.net.Uri
import android.content.ComponentName
import android.content.ContextWrapper
import android.os.Bundle
import android.os.SystemClock
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.Calendar
import java.util.Locale

private class PApp(val pkg: String, val name: String, val icon: Drawable?)

// قسم Focus: الرصيد، التطبيقات المنتجة، العادات، التطبيقات المستهلكة، وسجل الرصيد
class FocusPage(private val act: Activity) : ContextWrapper(act) {
    private lateinit var box: LinearLayout
    private lateinit var pageScroll: ScrollView
    private lateinit var pal: Pal
    private var logShown = 8
    private var sessionTimer: TextView? = null
    private var sessionProgress: ProgressBar? = null
    private val sessionHandler = Handler(Looper.getMainLooper())
    private val sessionTick = object : Runnable {
        override fun run() {
            val s = FocusStore.session
            val h = s?.let { FocusStore.habits.firstOrNull { habit -> habit.id == it.habitId } }
            if (s != null && h != null && s.state == "running") {
                updateSessionViews(h)
                sessionHandler.postDelayed(this, 1000L)
            }
        }
    }

    private fun dp(v: Int): Int = Ui.dp(this, v)

    // يبني صفحة Focus كعرض داخل شاشة التطبيق الرئيسية (تبقى أزرار الأقسام ظاهرة بالأسفل)
    fun build(): View {
        Lang.en = false
        FocusStore.init(this)
        FocusStore.reconcileSession(this)
        pal = PalGen.focus()
        box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.layoutDirection = Lang.dir
        box.setPadding(dp(18), dp(12), dp(18), dp(48))
        pageScroll = ScrollView(this)
        pageScroll.isFillViewport = true
        pageScroll.isVerticalScrollBarEnabled = false
        pageScroll.setBackgroundColor(Color.TRANSPARENT)
        // نفس عرض الواجهة الرئيسية (حد أقصى 520dp ومحاذاة للمنتصف)
        val pageW = minOf(resources.displayMetrics.widthPixels, dp(520))
        pageScroll.addView(box, android.widget.FrameLayout.LayoutParams(pageW, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER_HORIZONTAL))
        // الصفحة بكامل الشاشة وبنفس خلفية باقي التطبيق، وليست نافذة عائمة فوق ما قبلها
        val root = android.widget.FrameLayout(this)
        root.background = AppBgDrawable()
        root.addView(pageScroll, android.widget.FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        FocusWatchdog.schedule(this)
        askNotifications()
        return root
    }

    private fun notifOk(): Boolean =
        android.os.Build.VERSION.SDK_INT < 33 ||
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) == android.content.pm.PackageManager.PERMISSION_GRANTED

    // يطلب إذن الإشعارات مرة واحدة (أندرويد 13+) ليظهر تنبيه التوقف وتحذير الرصيد
    private fun askNotifications() {
        if (notifOk()) return
        val sp = getSharedPreferences("focus_ui", MODE_PRIVATE)
        if (sp.getBoolean("asked_notif", false)) return
        sp.edit().putBoolean("asked_notif", true).apply()
        try {
            act.requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 5501)
        } catch (e: Exception) {
        }
    }

    private fun openNotifSettings() {
        try {
            if (android.os.Build.VERSION.SDK_INT >= 26) {
                startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName))
            } else openAppInfo()
        } catch (e: Exception) {
            openAppInfo()
        }
    }

    // تُستدعى عند ظهور تبويب Focus أو العودة إلى التطبيق
    private var animateNext = false
    private var lastBal = 0.0

    fun onShow(animate: Boolean = true) {
        FocusStore.reconcileSession(this)
        animateNext = animate
        render()
    }

    fun onHide() {
        sessionHandler.removeCallbacks(sessionTick)
    }

    private fun onAccent(): Int = Color.parseColor("#1a1224")

    private fun num(s: String): Double? {
        val sb = StringBuilder()
        for (ch in s.trim()) {
            when {
                ch in '٠'..'٩' -> sb.append('0' + (ch - '٠'))
                ch == '٫' || ch == '،' || ch == ',' -> sb.append('.')
                else -> sb.append(ch)
            }
        }
        return sb.toString().toDoubleOrNull()
    }

    private fun icon(pkg: String): Drawable? = try {
        packageManager.getApplicationIcon(pkg)
    } catch (e: Exception) {
        null
    }

    private val okColor: Int = Color.parseColor("#65b891")
    private lateinit var host: LinearLayout

    // بطاقة بنفس شكل بطاقات التطبيق؛ كل ما يُضاف بعدها (head / hint / صفوف) يدخل داخلها
    private fun card(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(dp(16), dp(12), dp(16), dp(10))
        c.background = Ui.shape(pal.glass, pal.line, dp(16).toFloat(), dp(1))
        box.addView(c, Ui.lp(Ui.MP, Ui.WC, dp(14)))
        host = c
        return c
    }

    // عنوان القسم + زر الإضافة في نفس السطر
    private fun head(title: String, sub: String, actionLabel: String? = null, action: (() -> Unit)? = null) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.addView(Ui.tv(this, title, 16f, pal.fg, true), LinearLayout.LayoutParams(0, Ui.WC, 1f))
        if (actionLabel != null && action != null) {
            val a = Ui.tv(this, actionLabel, 14f, pal.accent, true)
            a.gravity = Gravity.CENTER
            a.setPadding(dp(8), 0, dp(8), 0)
            a.setOnClickListener { action() }
            row.addView(a, LinearLayout.LayoutParams(Ui.WC, dp(44)))
        }
        host.addView(row, Ui.lp(Ui.MP, Ui.WC))
        if (sub.isNotBlank()) host.addView(Ui.tv(this, sub, 12f, pal.muted), Ui.lp(Ui.MP, Ui.WC))
    }

    private fun hint(message: String) {
        val t = Ui.tv(this, message, 13f, pal.muted)
        t.setPadding(0, dp(8), 0, dp(10))
        host.addView(t, Ui.lp(Ui.MP, Ui.WC))
    }

    private fun checkRow(ok: Boolean, label: String, fix: (() -> Unit)?) {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.minimumHeight = dp(48)
        val mark = Ui.tv(this, if (ok) "✓" else "!", 16f, if (ok) okColor else pal.warn, true)
        mark.gravity = Gravity.CENTER
        r.addView(mark, LinearLayout.LayoutParams(dp(24), Ui.WC))
        val t = Ui.tv(this, label, 14f, pal.fg)
        t.setPadding(dp(10), 0, dp(10), 0)
        r.addView(t, LinearLayout.LayoutParams(0, Ui.WC, 1f))
        if (!ok && fix != null) {
            r.addView(Ui.tv(this, T("إصلاح", "Fix"), 14f, pal.accent, true))
            r.setOnClickListener { fix() }
        }
        host.addView(r, Ui.lp(Ui.MP, Ui.WC))
    }

    private fun batteryOk(): Boolean = try {
        (getSystemService(POWER_SERVICE) as android.os.PowerManager).isIgnoringBatteryOptimizations(packageName)
    } catch (e: Exception) {
        true
    }

    private fun isXiaomi(): Boolean {
        val m = android.os.Build.MANUFACTURER.lowercase()
        return m.contains("xiaomi") || m.contains("redmi") || m.contains("poco")
    }

    private fun openAppInfo() {
        try {
            val i = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
            i.data = Uri.parse("package:" + packageName)
            startActivity(i)
        } catch (e: Exception) {
        }
    }

    // نافذة النظام المباشرة: «السماح للتطبيق بالعمل دائمًا في الخلفية»
    private fun requestBattery() {
        try {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + packageName)))
        } catch (e: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            } catch (e2: Exception) {
                openAppInfo()
            }
        }
    }

    private fun openAutostart() {
        try {
            val i = Intent()
            i.component = ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity")
            startActivity(i)
        } catch (e: Exception) {
            openAppInfo()
        }
    }

    private fun fmtDur(sec: Double): String {
        val s = sec.toInt()
        return if (s < 60) s.toString() + T(" ث", " s") else (s / 60).toString() + T(" د", " min")
    }

    private fun fmtSession(ms: Long): String {
        val total = (ms / 1000L).coerceAtLeast(0L)
        val hours = total / 3600L
        val minutes = (total % 3600L) / 60L
        val seconds = total % 60L
        return String.format(Locale.US, "%02d:%02d:%02d", hours, minutes, seconds)
    }

    private fun updateSessionViews(h: FHabit) {
        val ms = FocusStore.elapsedSessionMs()
        sessionTimer?.text = fmtSession(ms)
        sessionProgress?.max = (h.targetMinutes * 60).coerceAtLeast(1)
        sessionProgress?.progress = (ms / 1000L).coerceIn(0L, (h.targetMinutes * 60).toLong()).toInt()
    }

    private fun startHabit(h: FHabit) {
        val current = FocusStore.session
        if (current != null && (current.state == "running" || current.state == "paused")) {
            Toast.makeText(this, T("أنهِ العادة الحالية أولًا", "Finish the current habit first"), Toast.LENGTH_SHORT).show()
            return
        }
        FocusStore.startSession(this, h.id)
        MainActivity.notifyFocusChanged()
        render()
    }

    private fun chooseHabit() {
        if (FocusStore.habits.isEmpty()) { habitDialog(null); return }
        val d = newDialog()
        val col = column()
        col.addView(Ui.tv(this, T("ابدأ عادة", "Start a habit"), 18f, pal.fg, true))
        for (h in FocusStore.habits) {
            val b = Ui.btn(this, h.title, Color.TRANSPARENT, pal.fg)
            b.gravity = if (Lang.en) Gravity.LEFT or Gravity.CENTER_VERTICAL else Gravity.RIGHT or Gravity.CENTER_VERTICAL
            b.minHeight = dp(48)
            b.setOnClickListener { d.dismiss(); startHabit(h) }
            col.addView(b, Ui.lp(Ui.MP, Ui.WC, dp(4)))
        }
        val cancel = Ui.btn(this, T("إلغاء", "Cancel"), Color.TRANSPARENT, pal.muted)
        cancel.minHeight = dp(44)
        cancel.setOnClickListener { d.dismiss() }
        col.addView(cancel, Ui.lp(Ui.MP, Ui.WC, dp(8)))
        showDialog(d, col)
    }

    private fun finishSession(h: FHabit) {
        val elapsed = FocusStore.elapsedSessionMs()
        when (h.kind) {
            1 -> { FocusStore.completeSession(); MainActivity.notifyFocusChanged(); reward((elapsed / 60000.0) * h.value, h) }
            2 -> { FocusStore.completeSession(); MainActivity.notifyFocusChanged(); reward(h.value, h) }
            else -> askNumber(h.title, T("كم نقطة تكسب من هذه الجلسة؟", "How much credit did you earn this session?")) { v ->
                FocusStore.completeSession()
                MainActivity.notifyFocusChanged()
                reward(v, h)
            }
        }
    }

    private fun sessionCard() {
        val s = FocusStore.session
        val h = s?.let { FocusStore.habits.firstOrNull { habit -> habit.id == it.habitId } }
        if (s != null && h == null) FocusStore.clearSession()
        val actual = FocusStore.session
        val habit = actual?.let { FocusStore.habits.firstOrNull { item -> item.id == it.habitId } }
        // لا نعرض أي بطاقة للعادات إلا أثناء جلسة نشطة (البدء من تبويب العادات)
        if (actual == null || habit == null) return
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(dp(16), dp(16), dp(16), dp(16))
        card.background = Ui.shape(
            if (actual?.state == "completed") PalGen.alpha(Color.parseColor("#65b891"), 34) else pal.glass,
            if (actual?.state == "completed") Color.parseColor("#65b891") else pal.line,
            dp(16).toFloat(), dp(1)
        )
        card.addView(Ui.tv(this, T("العادة الحالية", "Current habit"), 12f, pal.muted, true))
        if (actual == null || habit == null) {
            card.addView(Ui.tv(this, T("لا توجد عادة نشطة", "No active habit"), 20f, pal.fg, true), Ui.lp(Ui.MP, Ui.WC, dp(4)))
            card.addView(Ui.tv(this, T("افتح تبويب العادات واضغط ▶ على عادة لها مؤقّت لتبدأ جلسة.", "Open the Habits tab and tap ▶ on a timed habit to start a session."), 13f, pal.muted), Ui.lp(Ui.MP, Ui.WC, dp(4)))
            val start = Ui.btn(this, T("اذهب إلى العادات", "Go to Habits"), pal.accent, onAccent())
            start.minHeight = dp(56)
            start.contentDescription = T("ابدأ عادة", "Start a habit")
            start.setOnClickListener { MainActivity.gotoTab("habits") }
            card.addView(start, Ui.lp(Ui.MP, Ui.WC, dp(12)))
        } else {
            card.addView(Ui.tv(this, habit.title, 20f, pal.fg, true), Ui.lp(Ui.MP, Ui.WC, dp(4)))
            sessionTimer = Ui.tv(this, fmtSession(FocusStore.elapsedSessionMs()), 34f, pal.fg, true)
            sessionTimer?.typeface = android.graphics.Typeface.create("monospace", android.graphics.Typeface.BOLD)
            sessionTimer?.contentDescription = T("وقت الجلسة", "Session elapsed time")
            card.addView(sessionTimer, Ui.lp(Ui.MP, Ui.WC, dp(8)))
            sessionProgress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
            sessionProgress?.progressTintList = android.content.res.ColorStateList.valueOf(pal.accent)
            sessionProgress?.progressBackgroundTintList = android.content.res.ColorStateList.valueOf(PalGen.alpha(pal.fg, 32))
            sessionProgress?.max = (habit.targetMinutes * 60).coerceAtLeast(1)
            sessionProgress?.progress = (FocusStore.elapsedSessionMs() / 1000L).coerceIn(0L, (habit.targetMinutes * 60).toLong()).toInt()
            card.addView(sessionProgress, Ui.lp(Ui.MP, dp(8), dp(8)))
            card.addView(Ui.tv(this, T("الهدف: ", "Target: ") + habit.targetMinutes + T(" دقيقة", " min") + if (FocusStore.elapsedSessionMs() >= habit.targetMinutes * 60000L) T(" · وصلت للمدة", " · target reached") else "", 12f, pal.muted), Ui.lp(Ui.MP, Ui.WC, dp(8)))
            when (actual.state) {
                "running" -> {
                    val actions = LinearLayout(this)
                    actions.orientation = LinearLayout.HORIZONTAL
                    val pause = Ui.btn(this, T("إيقاف مؤقت", "Pause"), pal.accent, onAccent())
                    pause.minHeight = dp(52)
                    pause.contentDescription = T("إيقاف الجلسة مؤقتًا", "Pause the current session")
                    pause.setOnClickListener { FocusStore.pauseSession(); MainActivity.notifyFocusChanged(); sessionHandler.removeCallbacks(sessionTick); render() }
                    val done = Ui.btn(this, T("إنهاء", "Finish"), Color.TRANSPARENT, pal.fg)
                    done.minHeight = dp(52)
                    done.contentDescription = T("إنهاء الجلسة الحالية واحتساب المكافأة", "Finish the current session and claim its reward")
                    done.setOnClickListener { finishSession(habit) }
                    actions.addView(pause, LinearLayout.LayoutParams(0, Ui.WC, 1f).apply { marginEnd = dp(8) })
                    actions.addView(done, LinearLayout.LayoutParams(0, Ui.WC, 1f))
                    card.addView(actions, Ui.lp(Ui.MP, Ui.WC, dp(8)))
                    sessionHandler.removeCallbacks(sessionTick)
                    sessionHandler.post(sessionTick)
                }
                "paused" -> {
                    val actions = LinearLayout(this)
                    actions.orientation = LinearLayout.HORIZONTAL
                    val resume = Ui.btn(this, T("استئناف", "Resume"), pal.accent, onAccent())
                    resume.minHeight = dp(52)
                    resume.contentDescription = T("استئناف الجلسة الحالية", "Resume the current session")
                    resume.setOnClickListener { FocusStore.resumeSession(this); MainActivity.notifyFocusChanged(); render() }
                    val finish = Ui.btn(this, T("إنهاء الجلسة", "Finish session"), Color.TRANSPARENT, pal.fg)
                    finish.minHeight = dp(52)
                    finish.contentDescription = T("إنهاء الجلسة الحالية واحتساب المكافأة", "Finish the current session and claim its reward")
                    finish.setOnClickListener { finishSession(habit) }
                    actions.addView(resume, LinearLayout.LayoutParams(0, Ui.WC, 1f).apply { marginEnd = dp(8) })
                    actions.addView(finish, LinearLayout.LayoutParams(0, Ui.WC, 1f))
                    card.addView(actions, Ui.lp(Ui.MP, Ui.WC, dp(8)))
                }
                else -> {
                    card.addView(Ui.tv(this, T("اكتملت الجلسة بنجاح", "Session completed"), 14f, Color.parseColor("#65b891"), true), Ui.lp(Ui.MP, Ui.WC, dp(4)))
                    val another = Ui.btn(this, T("تم", "Done"), pal.accent, onAccent())
                    another.minHeight = dp(56)
                    another.setOnClickListener {
                        FocusStore.clearSession()
                        MainActivity.notifyFocusChanged()
                        render()
                    }
                    card.addView(another, Ui.lp(Ui.MP, Ui.WC, dp(8)))
                }
            }
        }
        box.addView(card, Ui.lp(Ui.MP, Ui.WC, dp(16)))
    }

    private fun render() {
        Lang.en = false // واجهة التطبيق عربية؛ لا نتبع لغة قائمة الودجت هنا
        sessionHandler.removeCallbacks(sessionTick)
        sessionTimer = null
        sessionProgress = null
        box.removeAllViews()
        host = box
        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        val title = Ui.tv(this, "Focus", 20f, pal.fg, true)
        title.setPadding(dp(4), 0, dp(6), 0)
        top.addView(title, LinearLayout.LayoutParams(0, Ui.WC, 1f))
        val healthy = isHealthy()
        val st = Ui.tv(this, if (healthy) T("● يعمل", "● Active") else T("● يحتاج إصلاح", "● Needs a fix"), 12f, if (healthy) okColor else pal.warn, true)
        st.setPadding(dp(10), dp(5), dp(10), dp(5))
        st.background = Ui.shape(PalGen.alpha(if (healthy) okColor else pal.warn, 28), 0, dp(12).toFloat())
        top.addView(st)
        box.addView(top, Ui.lp(Ui.MP, dp(48), dp(0)))
        balanceCard()
        sessionCard()
        healthCard()
        groupCard(true)
        groupCard(false)
        historyCard()
        settingsCard()
        // دخول متتابع للكروت (عند فتح التبويب فقط، وبحسب إعداد الحركات)
        if (animateNext && Store.flag(this, "anim")) {
            for (i in 0 until box.childCount) {
                val v = box.getChildAt(i)
                v.alpha = 0f
                v.translationY = dp(18).toFloat()
                v.animate().alpha(1f).translationY(0f).setStartDelay(i * 70L).setDuration(360)
                    .setInterpolator(android.view.animation.DecelerateInterpolator(1.6f)).start()
            }
        }
        animateNext = false
    }

    // الرصيد: أول وأوضح ما يراه المستخدم
    private fun balanceCard() {
        val c = card()
        c.background = Ui.shape(pal.glass, PalGen.alpha(pal.accent, 110), dp(16).toFloat(), dp(1))
        c.setPadding(dp(16), dp(14), dp(16), dp(14))
        c.addView(Ui.tv(this, T("رصيدك", "Your balance"), 13f, pal.muted))
        val balTv = Ui.tv(this, FocusStore.fmtFloor(FocusStore.bal), 44f, pal.fg, true)
        c.addView(balTv)
        if (Store.flag(this, "anim") && (animateNext || Math.abs(FocusStore.bal - lastBal) > 0.01)) {
            val from = if (animateNext) 0f else lastBal.toFloat()
            val va = android.animation.ValueAnimator.ofFloat(from, FocusStore.bal.toFloat())
            va.duration = 750
            va.interpolator = android.view.animation.DecelerateInterpolator(1.5f)
            va.addUpdateListener { balTv.text = FocusStore.fmtFloor((it.animatedValue as Float).toDouble()) }
            va.start()
        }
        lastBal = FocusStore.bal
        val stats = LinearLayout(this)
        stats.orientation = LinearLayout.HORIZONTAL
        stats.addView(Ui.tv(this, T("اليوم  ", "Today  ") + "+" + FocusStore.fmt(FocusStore.earnedNow()), 13f, pal.accent, true))
        val st2 = Ui.tv(this, "−" + FocusStore.fmt(FocusStore.spentNow()), 13f, pal.warn, true)
        st2.setPadding(dp(14), 0, 0, 0)
        stats.addView(st2)
        c.addView(stats, Ui.lp(Ui.MP, Ui.WC, dp(2)))
        if (FocusStore.debt > 0.05) {
            c.addView(Ui.tv(this, T("دين الطوارئ: ", "Emergency debt: ") + FocusStore.fmt(FocusStore.debt) + T(" — يُسدَّد من مكاسبك القادمة", " — repaid from your next earnings"), 12f, pal.warn), Ui.lp(Ui.MP, Ui.WC, dp(4)))
        }
        weekChart(c)
    }

    // رسم مصغّر لآخر 7 أيام: عمود أخضر للكسب وآخر للإنفاق، ويُخفى إن لم تكن هناك حركات
    private fun weekChart(c: LinearLayout) {
        val earn = DoubleArray(7)
        val spent = DoubleArray(7)
        val keys = IntArray(7)
        val labels = Array(7) { "" }
        val nowMs = System.currentTimeMillis()
        for (k in 0 until 7) {
            val ts = nowMs - (6 - k) * 86400000L
            keys[k] = dayKeyOf(ts)
            val cal = Calendar.getInstance()
            cal.timeInMillis = ts
            labels[k] = cal.get(Calendar.DAY_OF_MONTH).toString()
        }
        for (l in FocusStore.log) {
            val k = keys.indexOf(dayKeyOf(l.ts))
            if (k < 0) continue
            if (l.delta > 0) earn[k] += l.delta else spent[k] -= l.delta
        }
        var any = false
        for (k in 0 until 7) if (earn[k] > 0.0 || spent[k] > 0.0) any = true
        if (!any) return
        val wb = WeekBars(this, earn, spent, labels, pal.accent, pal.warn, pal.muted)
        c.addView(wb, Ui.lp(Ui.MP, dp(64), dp(10)))
        if (animateNext && Store.flag(this, "anim")) wb.grow()
    }

    // حالة التشغيل: سطر واحد حين يكون كل شيء سليمًا، وخطوات إصلاح واضحة حين لا يكون
    private fun healthCard() {
        val svcOn = FocusService.enabled(this)
        val ago = if (FocusStore.hb == 0L) -1L else (SystemClock.elapsedRealtime() - FocusStore.hb) / 1000
        val alive = svcOn && ago in 0L..8L
        val batt = batteryOk()
        val notif = notifOk()
        if (alive && batt && notif) return
        card()
        host.addView(Ui.tv(this, T("Focus يحتاج خطوة ليعمل دائمًا", "Focus needs a step to work all the time"), 15f, pal.warn, true))
        if (!alive) {
            checkRow(
                false,
                if (svcOn) T("المراقبة متوقفة — أوقف الخدمة ثم شغّلها", "Monitoring stopped — turn the service off and on") else T("تفعيل خدمة المراقبة", "Turn on the monitoring service"),
                { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
            )
            if (!svcOn) {
                val h = Ui.tv(this, T("الخيار رمادي؟ معلومات التطبيق ← ⋮ ← السماح بالإعدادات المقيّدة (اضغط للفتح)", "Greyed out? App info → ⋮ → Allow restricted settings (tap to open)"), 12f, pal.muted)
                h.setOnClickListener { openAppInfo() }
                host.addView(h, Ui.lp(Ui.MP, Ui.WC, dp(2)))
            }
        }
        if (!batt) checkRow(false, T("السماح بالعمل في الخلفية", "Allow background activity"), { requestBattery() })
        if (!notif) checkRow(false, T("السماح بالإشعارات", "Allow notifications"), { openNotifSettings() })
    }

    private fun habitsCard() {
        card()
        head(
            T("العادات", "Habits"),
            T("ابدأ جلسة ثم أنهِها لتكسب المكافأة. ويمكنك ربط مكافأة بمهمة من شاشة إضافتها.", "Start a session, then finish it to earn the reward. You can also attach a reward to a task."),
            T("+ عادة", "+ Habit"),
            { habitDialog(null) }
        )
        if (FocusStore.habits.isEmpty()) hint(T("أضف عادة بسيطة مثل القراءة أو التمرين.", "Add a simple habit like reading or exercise."))
        for (h in FocusStore.habits) habitRow(h)
    }

    private fun appsCard(earn: Boolean) {
        card()
        val list = if (earn) FocusStore.earn else FocusStore.spend
        head(
            if (earn) T("تطبيقات تكسب", "Apps that earn") else T("تطبيقات تستهلك", "Apps that spend"),
            if (earn) T("تكسب رصيدًا عن كل دقيقة استخدام.", "Earn credit for every minute of use.") else T("تُخصم كل دقيقة، ويُحظر التطبيق عند نفاد الرصيد.", "Each minute costs credit; the app is blocked when credit runs out."),
            T("+ تطبيق", "+ App"),
            { pickApp(earn) }
        )
        if (list.isEmpty()) hint(if (earn) T("اختياري: أضف تطبيق تعلّم أو قراءة أو عمل.", "Optional: add a learning, reading or work app.") else T("لن يحظر Focus أي تطبيق حتى تضيفه هنا.", "Focus will not block any app until you add one here."))
        for (a in list) appRow(a, earn)
    }

    // ---------- كروت الإنتاج والاستهلاك والسجل ----------
    private val expanded = HashSet<String>()
    private var histFilter = 0 // 0 الكل، 1 كسب، 2 إنفاق

    private fun isHealthy(): Boolean {
        val svcOn = FocusService.enabled(this)
        val ago = if (FocusStore.hb == 0L) -1L else (SystemClock.elapsedRealtime() - FocusStore.hb) / 1000
        return svcOn && ago in 0L..8L && batteryOk() && notifOk()
    }

    // مجموع الكسب/الإنفاق لآخر 7 أيام (آخر عنصر = اليوم)
    private fun dayTotals(): Pair<DoubleArray, DoubleArray> {
        val earn = DoubleArray(7)
        val spent = DoubleArray(7)
        val keys = IntArray(7)
        val nowMs = System.currentTimeMillis()
        for (k in 0 until 7) keys[k] = dayKeyOf(nowMs - (6 - k) * 86400000L)
        for (l in FocusStore.log) {
            val k = keys.indexOf(dayKeyOf(l.ts))
            if (k < 0) continue
            if (l.delta > 0) earn[k] += l.delta else spent[k] -= l.delta
        }
        return Pair(earn, spent)
    }

    // تجمّع أيقونات التطبيقات (حتى 4، أو 3 + شارة "+N")
    private fun clusterTile(list: List<FApp>): android.widget.FrameLayout {
        val t = android.widget.FrameLayout(this)
        t.background = Ui.shape(PalGen.alpha(pal.fg, 10), 0, dp(18).toFloat())
        if (list.isEmpty()) {
            val plus = Ui.tv(this, "+", 30f, pal.accent, true)
            plus.gravity = Gravity.CENTER
            t.addView(plus, android.widget.FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            return t
        }
        val pos = arrayOf(intArrayOf(10, 10), intArrayOf(36, 10), intArrayOf(10, 36), intArrayOf(36, 36))
        val shown = if (list.size <= 4) list else list.take(3)
        for ((i, a) in shown.withIndex()) {
            val iv = ImageView(this)
            iv.setImageDrawable(icon(a.pkg))
            val lp = android.widget.FrameLayout.LayoutParams(dp(22), dp(22))
            lp.leftMargin = dp(pos[i][0])
            lp.topMargin = dp(pos[i][1])
            t.addView(iv, lp)
        }
        if (list.size > 4) {
            val badge = Ui.tv(this, "+" + (list.size - 3), 11f, pal.fg, true)
            badge.gravity = Gravity.CENTER
            badge.setPadding(dp(6), 0, dp(6), 0)
            badge.background = Ui.shape(Color.parseColor("#2a2338"), pal.glass, dp(10).toFloat(), dp(2))
            val lp = android.widget.FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(22))
            lp.leftMargin = dp(36)
            lp.topMargin = dp(36)
            t.addView(badge, lp)
        }
        return t
    }

    private fun toggleSwitch(on: Boolean, change: (Boolean) -> Unit): android.widget.Switch {
        val sw = android.widget.Switch(this)
        sw.isChecked = on
        sw.thumbTintList = android.content.res.ColorStateList.valueOf(Color.WHITE)
        sw.trackTintList = android.content.res.ColorStateList(
            arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
            intArrayOf(okColor, pal.line)
        )
        sw.setOnCheckedChangeListener { _, v -> change(v) }
        return sw
    }

    // كارت مجموعة: تجمّع أيقونات + عنوان + مفتاح تشغيل + حالة + شريط تقدّم + إدارة التطبيقات
    private fun groupCard(earn: Boolean) {
        val list = if (earn) FocusStore.earn else FocusStore.spend
        val on = if (earn) FocusStore.earnOn else FocusStore.spendOn
        val key = if (earn) "earn" else "spend"
        val tone = if (earn) pal.accent else pal.warn
        val c = card()
        c.setPadding(dp(16), dp(16), dp(16), dp(6))
        c.background = Ui.shape(pal.glass, if (on && list.isNotEmpty()) PalGen.alpha(tone, 90) else pal.line, dp(22).toFloat(), dp(1))

        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        val tile = clusterTile(list)
        tile.setOnClickListener {
            if (list.isEmpty()) pickApp(earn)
            else {
                if (!expanded.add(key)) expanded.remove(key)
                render()
            }
        }
        top.addView(tile, LinearLayout.LayoutParams(dp(68), dp(68)))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(14), 0, dp(10), 0)
        col.addView(Ui.tv(this, if (earn) T("الإنتاج", "Production") else T("الاستهلاك", "Consumption"), 18f, pal.fg, true))
        val today = if (earn) "+" + FocusStore.fmt(FocusStore.earnedNow()) else "−" + FocusStore.fmt(FocusStore.spentNow())
        col.addView(Ui.tv(this, T("اليوم  ", "Today  ") + today, 13f, tone, true), Ui.lp(Ui.MP, Ui.WC, dp(2)))
        top.addView(col, LinearLayout.LayoutParams(0, Ui.WC, 1f))
        top.addView(toggleSwitch(on) { v ->
            if (earn) {
                FocusStore.earnOn = v
                FocusStore.save(true)
                render()
            } else if (v) {
                FocusStore.spendOn = true
                FocusStore.save(true)
                render()
            } else {
                android.app.AlertDialog.Builder(act)
                    .setTitle(T("إيقاف الاستهلاك؟", "Pause consumption?"))
                    .setMessage(T("لن يُخصم رصيد ولن يُحظر أي تطبيق مستهلك حتى تعيد التشغيل.", "No credit will be spent and no limited app will be blocked until you turn it back on."))
                    .setPositiveButton(T("إيقاف", "Pause")) { _, _ ->
                        FocusStore.spendOn = false
                        FocusStore.save(true)
                        render()
                    }
                    .setNegativeButton(T("إلغاء", "Cancel")) { _, _ -> render() }
                    .setOnCancelListener { render() }
                    .show()
            }
        })
        c.addView(top, Ui.lp(Ui.MP, Ui.WC))

        // حالة المجموعة
        val bal = FocusStore.bal
        val maxRate = list.maxOfOrNull { it.rate } ?: 0.0
        val status = when {
            list.isEmpty() -> if (earn) T("أضف تطبيقًا ليبدأ الكسب", "Add an app to start earning") else T("لن يُحظر أي تطبيق حتى تضيفه", "Nothing is blocked until you add an app")
            !on -> if (earn) T("الكسب متوقف", "Earning is paused") else T("الاستهلاك متوقف — لا خصم ولا حظر", "Paused — no spending, no blocking")
            earn -> if (FocusStore.cap > 0.0 && FocusStore.earnedNow() >= FocusStore.cap) T("بلغت الحد اليومي للمكافآت", "Daily reward cap reached") else T("يكسب رصيدًا عن كل دقيقة استخدام", "Earns credit for every minute of use")
            bal <= 0.0 -> T("الرصيد نفد — التطبيقات محظورة", "Out of credit — apps are blocked")
            maxRate > 0.0 -> T("الرصيد يكفي ~", "Credit lasts ~") + Math.max(1, Math.floor(bal / maxRate).toInt()) + T(" دقيقة", " min")
            else -> T("رصيدك متاح", "Credit available")
        }
        val pill = Ui.tv(this, status, 14f, if (!on || list.isEmpty()) pal.muted else pal.fg, true)
        pill.gravity = Gravity.CENTER
        pill.setPadding(dp(12), dp(14), dp(12), dp(14))
        pill.background = Ui.shape(PalGen.alpha(pal.fg, 10), 0, dp(16).toFloat())
        c.addView(pill, Ui.lp(Ui.MP, Ui.WC, dp(14)))

        // سطر التقدّم: الأكثر استخدامًا اليوم + شريط
        if (list.isNotEmpty()) {
            val (e7, s7) = dayTotals()
            val earned = FocusStore.earnedNow()
            val spent = FocusStore.spentNow()
            val denom: Double
            val label: String
            val ratio: Double
            if (earn) {
                var best = earned
                for (v in e7) best = Math.max(best, v)
                denom = if (FocusStore.cap > 0.0) FocusStore.cap else Math.max(best, 1.0)
                ratio = earned / denom
                label = "+" + FocusStore.fmt(earned) + " / " + FocusStore.fmt(denom)
            } else {
                denom = spent + Math.max(bal, 0.0)
                ratio = if (denom > 0.0) spent / denom else 0.0
                label = "−" + FocusStore.fmt(spent) + " / " + FocusStore.fmt(denom)
            }
            val r = ratio.coerceIn(0.0, 1.0).toFloat()
            val rowP = LinearLayout(this)
            rowP.orientation = LinearLayout.HORIZONTAL
            rowP.gravity = Gravity.CENTER_VERTICAL
            rowP.addView(Ui.tv(this, "◷", 20f, tone, true))
            val used = list.filter { it.today > 0.0 }.sortedByDescending { it.today }.take(3)
            for (a in used) {
                val iv = ImageView(this)
                iv.setImageDrawable(icon(a.pkg))
                val lp = LinearLayout.LayoutParams(dp(22), dp(22))
                lp.marginStart = dp(8)
                rowP.addView(iv, lp)
            }
            val sp = View(this)
            rowP.addView(sp, LinearLayout.LayoutParams(0, 1, 1f))
            rowP.addView(Ui.tv(this, label, 13f, pal.muted))
            c.addView(rowP, Ui.lp(Ui.MP, Ui.WC, dp(14)))
            val bar = LinearLayout(this)
            bar.orientation = LinearLayout.HORIZONTAL
            bar.background = Ui.shape(PalGen.alpha(pal.fg, 18), 0, dp(3).toFloat())
            val fill = View(this)
            fill.background = Ui.shape(if (on) tone else pal.line, 0, dp(3).toFloat())
            bar.addView(fill, LinearLayout.LayoutParams(0, dp(6), r.coerceAtLeast(0.001f)))
            bar.addView(View(this), LinearLayout.LayoutParams(0, dp(6), (1f - r).coerceAtLeast(0.001f)))
            c.addView(bar, Ui.lp(Ui.MP, dp(6), dp(8)))
            if (animateNext && Store.flag(this, "anim")) {
                fill.post {
                    fill.pivotX = if (box.layoutDirection == View.LAYOUT_DIRECTION_RTL) fill.width.toFloat() else 0f
                    fill.scaleX = 0f
                    fill.animate().scaleX(1f).setStartDelay(350).setDuration(750)
                        .setInterpolator(android.view.animation.DecelerateInterpolator(1.8f)).start()
                }
            }
        }

        // إدارة التطبيقات
        val open = expanded.contains(key)
        val manage = Ui.tv(
            this,
            if (list.isEmpty()) T("+ إضافة تطبيق", "+ Add app") else if (open) T("إخفاء التطبيقات ⌃", "Hide apps ⌃") else T("إدارة التطبيقات (", "Manage apps (") + list.size + ") ⌄",
            14f, pal.accent, true
        )
        manage.gravity = Gravity.CENTER
        manage.minHeight = dp(48)
        manage.setOnClickListener {
            if (list.isEmpty()) pickApp(earn)
            else {
                if (!expanded.add(key)) expanded.remove(key)
                render()
            }
        }
        if (open) {
            for (a in list) appRow(a, earn)
            val add = Ui.tv(this, T("+ إضافة تطبيق", "+ Add app"), 14f, pal.accent, true)
            add.gravity = Gravity.CENTER
            add.minHeight = dp(44)
            add.setOnClickListener { pickApp(earn) }
            host.addView(add, Ui.lp(Ui.MP, Ui.WC))
        }
        c.addView(manage, Ui.lp(Ui.MP, Ui.WC, dp(4)))
    }

    private fun filterPill(text: String, idx: Int): TextView {
        val on = histFilter == idx
        val v = Ui.tv(this, text, 13f, if (on) pal.accent else pal.muted, true)
        v.gravity = Gravity.CENTER
        v.setPadding(dp(14), dp(7), dp(14), dp(7))
        v.background = Ui.shape(if (on) PalGen.alpha(pal.accent, 40) else PalGen.alpha(pal.fg, 10), if (on) PalGen.alpha(pal.accent, 120) else 0, dp(14).toFloat(), if (on) dp(1) else 0)
        v.setOnClickListener {
            histFilter = idx
            logShown = 8
            render()
        }
        return v
    }

    private fun historyCard() {
        val c = card()
        c.setPadding(dp(16), dp(14), dp(16), dp(8))
        c.background = Ui.shape(pal.glass, pal.line, dp(22).toFloat(), dp(1))
        head(T("السجل", "History"), "")
        val pills = LinearLayout(this)
        pills.orientation = LinearLayout.HORIZONTAL
        pills.addView(filterPill(T("الكل", "All"), 0))
        val p1 = filterPill(T("كسب", "Earned"), 1)
        val p2 = filterPill(T("إنفاق", "Spent"), 2)
        pills.addView(p1, Ui.lp(Ui.WC, Ui.WC).also { (it as LinearLayout.LayoutParams).marginStart = dp(8) })
        pills.addView(p2, Ui.lp(Ui.WC, Ui.WC).also { (it as LinearLayout.LayoutParams).marginStart = dp(8) })
        c.addView(pills, Ui.lp(Ui.MP, Ui.WC, dp(4)))

        val all = FocusStore.log.filter { if (histFilter == 1) it.delta > 0 else if (histFilter == 2) it.delta < 0 else true }
        if (all.isEmpty()) hint(T("لا حركات بعد.", "No activity yet."))
        val net = HashMap<Int, Double>()
        for (l in all) net[dayKeyOf(l.ts)] = (net[dayKeyOf(l.ts)] ?: 0.0) + l.delta
        var lastDay = -1
        for (l in all.take(logShown)) {
            val dk = dayKeyOf(l.ts)
            if (dk != lastDay) {
                lastDay = dk
                val hd = LinearLayout(this)
                hd.orientation = LinearLayout.HORIZONTAL
                hd.setPadding(0, dp(12), 0, dp(2))
                hd.addView(Ui.tv(this, dayLabel(l.ts), 12f, pal.muted, true), LinearLayout.LayoutParams(0, Ui.WC, 1f))
                val n = net[dk] ?: 0.0
                hd.addView(Ui.tv(this, (if (n >= 0) "+" else "−") + FocusStore.fmt(Math.abs(n)), 12f, if (n >= 0) pal.accent else pal.warn, true))
                host.addView(hd, Ui.lp(Ui.MP, Ui.WC))
            }
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(0, dp(8), 0, dp(8))
            val pos = l.delta > 0
            val zero = l.delta == 0.0
            val dot = View(this)
            dot.background = Ui.shape(if (zero) pal.muted else if (pos) pal.accent else pal.warn, 0, dp(4).toFloat())
            val dlp = LinearLayout.LayoutParams(dp(8), dp(8))
            dlp.marginEnd = dp(12)
            row.addView(dot, dlp)
            val lab = Ui.tv(this, l.label, 14f, pal.fg)
            lab.maxLines = 1
            lab.ellipsize = android.text.TextUtils.TruncateAt.END
            row.addView(lab, LinearLayout.LayoutParams(0, Ui.WC, 1f))
            val tm = Ui.tv(this, timeStr(l.ts), 11f, pal.muted)
            tm.setPadding(dp(8), 0, dp(10), 0)
            row.addView(tm)
            row.addView(Ui.tv(this, if (zero) "•" else (if (pos) "+" else "−") + FocusStore.fmt(Math.abs(l.delta)), 14f, if (zero) pal.muted else if (pos) pal.accent else pal.warn, true))
            host.addView(row, Ui.lp(Ui.MP, Ui.WC))
        }
        if (all.size > logShown) {
            val more = Ui.tv(this, T("عرض المزيد", "Show more"), 14f, pal.accent, true)
            more.gravity = Gravity.CENTER
            more.minHeight = dp(48)
            more.setOnClickListener {
                logShown += 20
                render()
            }
            host.addView(more, Ui.lp(Ui.MP, Ui.WC, dp(4)))
        }
    }

    private fun settingsCard() {
        card()
        head(T("الإعدادات", "Settings"), "")
        val capTxt = if (FocusStore.cap > 0.0) T("الحد اليومي للمكافآت: ", "Daily reward cap: ") + FocusStore.fmt(FocusStore.earnedNow()) + " / " + FocusStore.fmt(FocusStore.cap)
        else T("الحد اليومي للمكافآت: بلا حد", "Daily reward cap: none")
        val capV = Ui.tv(this, capTxt + "  ✎", 14f, pal.fg)
        capV.gravity = Gravity.CENTER_VERTICAL
        capV.minHeight = dp(48)
        capV.setOnClickListener {
            askNumber(T("الحد اليومي للمكافآت", "Daily reward cap"), T("أقصى رصيد يُكسب في اليوم (0 = بلا حد)", "Max credit earned per day (0 = no cap)"), true, if (FocusStore.cap > 0.0) FocusStore.fmt(FocusStore.cap) else "") { v ->
                FocusStore.cap = v
                FocusStore.save(true)
                render()
            }
        }
        host.addView(capV, Ui.lp(Ui.MP, Ui.WC))
        if (FocusStore.cap > 0.0) {
            val ratio = (FocusStore.earnedNow() / FocusStore.cap).coerceIn(0.0, 1.0).toFloat()
            val bar = LinearLayout(this)
            bar.orientation = LinearLayout.HORIZONTAL
            bar.background = Ui.shape(PalGen.alpha(pal.fg, 30), 0, dp(3).toFloat())
            val fill = View(this)
            fill.background = Ui.shape(if (ratio >= 1f) pal.warn else pal.accent, 0, dp(3).toFloat())
            bar.addView(fill, LinearLayout.LayoutParams(0, dp(6), ratio.coerceAtLeast(0.001f)))
            bar.addView(View(this), LinearLayout.LayoutParams(0, dp(6), (1f - ratio).coerceAtLeast(0.001f)))
            host.addView(bar, Ui.lp(Ui.MP, dp(6)))
        }
        if (isXiaomi()) {
            val au = Ui.tv(this, T("التشغيل التلقائي (شاومي)", "Autostart (Xiaomi)") + "  ›", 14f, pal.fg)
            au.gravity = Gravity.CENTER_VERTICAL
            au.minHeight = dp(48)
            au.setOnClickListener { openAutostart() }
            host.addView(au, Ui.lp(Ui.MP, Ui.WC))
        }
    }

    private fun dayKeyOf(ts: Long): Int {
        val c = Calendar.getInstance()
        c.timeInMillis = ts
        return c.get(Calendar.YEAR) * 1000 + c.get(Calendar.DAY_OF_YEAR)
    }

    private fun dayLabel(ts: Long): String {
        val k = dayKeyOf(ts)
        if (k == dayKeyOf(System.currentTimeMillis())) return T("اليوم", "Today")
        if (k == dayKeyOf(System.currentTimeMillis() - 86400000L)) return T("أمس", "Yesterday")
        val c = Calendar.getInstance()
        c.timeInMillis = ts
        return c.get(Calendar.DAY_OF_MONTH).toString() + "/" + (c.get(Calendar.MONTH) + 1)
    }

    private fun timeStr(ts: Long): String {
        val c = Calendar.getInstance()
        c.timeInMillis = ts
        return String.format(Locale.US, "%02d:%02d", c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE))
    }

    private fun appRow(a: FApp, earn: Boolean) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(0, dp(9), 0, dp(9))
        val ic = ImageView(this)
        ic.setImageDrawable(icon(a.pkg))
        row.addView(ic, LinearLayout.LayoutParams(dp(32), dp(32)))
        val nmCol = LinearLayout(this)
        nmCol.orientation = LinearLayout.VERTICAL
        nmCol.setPadding(dp(12), 0, dp(12), 0)
        nmCol.addView(Ui.tv(this, a.name, 15f, pal.fg))
        nmCol.addView(Ui.tv(this, T("اليوم: ", "Today: ") + fmtDur(a.today), 11f, pal.muted))
        row.addView(nmCol, LinearLayout.LayoutParams(0, Ui.WC, 1f))
        val txt = (if (earn) "+" else "−") + FocusStore.fmt(a.rate) + T(" / دقيقة", " /min")
        row.addView(Ui.tv(this, txt, 13f, if (earn) pal.accent else pal.warn, true))
        val editMark = Ui.tv(this, "  ›", 18f, pal.muted)
        row.addView(editMark)
        row.contentDescription = T("اضغط لتعديل معدل التطبيق: ", "Tap to edit app rate: ") + a.name
        row.setOnClickListener { rateDialog(a, earn, a.pkg, a.name) }
        host.addView(row, Ui.lp(Ui.MP, Ui.WC))
    }

    private fun rewardText(h: FHabit): String = when (h.kind) {
        1 -> "+" + FocusStore.fmt(h.value) + T(" / دقيقة", " /min")
        2 -> "+" + FocusStore.fmt(h.value) + T(" عند الإنجاز", " on done")
        else -> T("مكافأة يدوية", "Manual reward")
    }

    private fun habitRow(h: FHabit) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(0, dp(9), 0, dp(9))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.addView(Ui.tv(this, h.title, 15f, pal.fg))
        col.addView(Ui.tv(this, rewardText(h), 12f, pal.muted))
        row.addView(col, LinearLayout.LayoutParams(0, Ui.WC, 1f))
        val current = FocusStore.session
        val label = if (current?.habitId == h.id && current.state in setOf("running", "paused")) T("نشطة", "Active") else T("ابدأ", "Start")
        val start = Ui.chip(this, label, pal, current?.habitId == h.id && current.state in setOf("running", "paused"))
        start.minHeight = dp(44)
        start.contentDescription = T("بدء جلسة العادة: ", "Start habit session: ") + h.title
        start.setOnClickListener { startHabit(h) }
        row.addView(start)
        row.addView(Ui.tv(this, "  ✎", 14f, pal.muted))
        row.contentDescription = T("اضغط لتعديل العادة: ", "Tap to edit habit: ") + h.title
        row.setOnClickListener { habitDialog(h) }
        host.addView(row, Ui.lp(Ui.MP, Ui.WC))
    }

    private fun reward(v: Double, h: FHabit) {
        val a = FocusStore.add(v, h.title, "h:" + h.id, false)
        if (a > 0) {
            h.last = System.currentTimeMillis()
            FocusStore.save(true)
            Toast.makeText(this, "+" + FocusStore.fmt(a), Toast.LENGTH_SHORT).show()
        } else if (FocusStore.capReached()) {
            Toast.makeText(this, T("وصلت للحد اليومي للمكافآت", "Daily reward cap reached"), Toast.LENGTH_SHORT).show()
        }
        HabitsData.markDoneToday(this, h.id, if (a > 0) a else 0.0)
        try {
            startActivity(Intent(this, CelebrateActivity::class.java).putExtra("fx", 2).putExtra("rw", if (a > 0) a else 0.0))
        } catch (e: Exception) {
        }
        MainActivity.notifyDataChanged()
        MainActivity.notifyFocusChanged()
        render()
    }

    // ---------- نوافذ ----------

    private fun newDialog(): Dialog {
        val d = Dialog(this, android.R.style.Theme_DeviceDefault_Dialog_NoActionBar)
        return d
    }

    private fun showDialog(d: Dialog, col: View) {
        d.setContentView(col)
        val w = d.window
        if (w != null) {
            w.setBackgroundDrawable(Ui.shape(pal.glass or (0xFF shl 24), pal.line, dp(22).toFloat(), 1))
            w.setLayout((resources.displayMetrics.widthPixels * 0.9f).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT)
        }
        d.show()
    }

    private fun column(): LinearLayout {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.layoutDirection = Lang.dir
        col.setPadding(dp(18), dp(16), dp(18), dp(14))
        return col
    }

    private fun edit(hint: String, text: String, numeric: Boolean): EditText {
        val e = EditText(this)
        e.setSingleLine(true)
        e.hint = hint
        e.setText(text)
        e.setTextColor(pal.fg)
        e.setHintTextColor(pal.muted)
        e.textSize = 15f
        e.background = Ui.shape(PalGen.alpha(pal.fg, 18), 0, dp(12).toFloat())
        e.setPadding(dp(12), dp(10), dp(12), dp(10))
        if (numeric) e.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        return e
    }

    // صف أزرار متساوية: حفظ / (حذف بتأكيد) / إلغاء
    private fun buttons(d: Dialog, saveText: String, onSave: () -> Unit, onDelete: (() -> Unit)?): LinearLayout {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        fun style(b: TextView) {
            b.textSize = 15f
            b.maxLines = 1
            b.minHeight = dp(44)
            b.setPadding(dp(6), dp(12), dp(6), dp(12))
        }
        val save = Ui.btn(this, saveText, pal.accent, onAccent())
        style(save)
        save.setOnClickListener { onSave() }
        val lp1 = LinearLayout.LayoutParams(0, Ui.WC, 1f)
        lp1.marginEnd = dp(6)
        row.addView(save, lp1)
        if (onDelete != null) {
            val del = Ui.btn(this, T("حذف", "Delete"), Color.TRANSPARENT, pal.warn)
            style(del)
            var armed = false
            del.setOnClickListener {
                if (!armed) {
                    armed = true
                    del.text = T("تأكيد الحذف", "Confirm delete")
                } else onDelete()
            }
            val lp2 = LinearLayout.LayoutParams(0, Ui.WC, 1f)
            lp2.marginEnd = dp(6)
            row.addView(del, lp2)
        }
        val cancel = Ui.btn(this, T("إلغاء", "Cancel"), Color.TRANSPARENT, pal.muted)
        style(cancel)
        cancel.setOnClickListener { d.dismiss() }
        row.addView(cancel, LinearLayout.LayoutParams(0, Ui.WC, 1f))
        return row
    }

    private fun askNumber(title: String, label: String, allowZero: Boolean = false, initial: String = "", cb: (Double) -> Unit) {
        val d = newDialog()
        val col = column()
        col.addView(Ui.tv(this, title, 17f, pal.fg, true))
        col.addView(Ui.tv(this, label, 13f, pal.muted), Ui.lp(Ui.MP, Ui.WC, dp(4)))
        val e = edit("", initial, true)
        col.addView(e, Ui.lp(Ui.MP, Ui.WC, dp(10)))
        col.addView(buttons(d, T("تم", "OK"), {
            val v = num(e.text.toString())
            if (v == null || v < 0.0 || (!allowZero && v <= 0.0)) {
                Toast.makeText(this, if (allowZero) T("أدخل رقمًا صحيحًا", "Enter a valid number") else T("أدخل رقمًا أكبر من صفر", "Enter a number above zero"), Toast.LENGTH_SHORT).show()
            } else {
                d.dismiss()
                cb(v)
            }
        }, null), Ui.lp(Ui.MP, Ui.WC, dp(14)))
        showDialog(d, col)
    }

    private fun rateDialog(existing: FApp?, earn: Boolean, pkg: String, name: String) {
        val d = newDialog()
        val col = column()
        col.addView(Ui.tv(this, name, 17f, pal.fg, true))
        val q = if (earn) T("كم تكسب لكل دقيقة استخدام؟", "Credit earned per minute of use") else T("كم تكلّف الدقيقة من الرصيد؟", "Credit cost per minute")
        col.addView(Ui.tv(this, q, 13f, pal.muted), Ui.lp(Ui.MP, Ui.WC, dp(4)))
        val e = edit("1", FocusStore.fmt(existing?.rate ?: 1.0), true)
        col.addView(e, Ui.lp(Ui.MP, Ui.WC, dp(10)))
        val del: (() -> Unit)? = if (existing == null) null else {
            {
                if (earn) FocusStore.earn.remove(existing) else FocusStore.spend.remove(existing)
                FocusStore.save(true)
                d.dismiss()
                render()
            }
        }
        col.addView(buttons(d, T("حفظ", "Save"), {
            val v = num(e.text.toString())
            if (v == null || v <= 0.0) {
                Toast.makeText(this, T("أدخل رقمًا أكبر من صفر", "Enter a number above zero"), Toast.LENGTH_SHORT).show()
            } else {
                if (existing != null) existing.rate = v
                else if (earn) FocusStore.earn.add(FApp(pkg, name, v))
                else FocusStore.spend.add(FApp(pkg, name, v))
                FocusStore.save(true)
                d.dismiss()
                render()
            }
        }, del), Ui.lp(Ui.MP, Ui.WC, dp(14)))
        showDialog(d, col)
    }

    private fun habitDialog(h: FHabit?) {
        val d = newDialog()
        val col = column()
        col.addView(Ui.tv(this, if (h == null) T("عادة جديدة", "New habit") else T("تعديل العادة", "Edit habit"), 17f, pal.fg, true))
        val title = edit(T("اسم العادة", "Habit name"), h?.title ?: "", false)
        col.addView(title, Ui.lp(Ui.MP, Ui.WC, dp(10)))
        var kind = h?.kind ?: 2
        val names = arrayOf(T("يدوي", "Manual"), T("لكل دقيقة", "Per minute"), T("ثابت", "Fixed"))
        val chips = LinearLayout(this)
        chips.orientation = LinearLayout.HORIZONTAL
        col.addView(chips, Ui.lp(Ui.MP, Ui.WC, dp(10)))
        val hint = Ui.tv(this, "", 13f, pal.muted)
        col.addView(hint, Ui.lp(Ui.MP, Ui.WC, dp(10)))
        val value = edit("1", FocusStore.fmt(h?.value ?: 1.0), true)
        col.addView(value, Ui.lp(Ui.MP, Ui.WC, dp(6)))
        val target = edit(T("مدة الجلسة بالدقائق", "Session target in minutes"), (h?.targetMinutes ?: 25).toString(), true)
        col.addView(target, Ui.lp(Ui.MP, Ui.WC, dp(6)))
        fun paint() {
            chips.removeAllViews()
            for (i in 0..2) {
                val c = Ui.chip(this, names[i], pal, kind == i)
                c.setOnClickListener {
                    kind = i
                    paint()
                }
                val lp = LinearLayout.LayoutParams(0, Ui.WC, 1f)
                lp.marginEnd = dp(6)
                chips.addView(c, lp)
            }
            value.visibility = if (kind == 0) View.GONE else View.VISIBLE
            hint.text = when (kind) {
                0 -> T("تحدد المكافأة بنفسك عند كل إتمام", "You enter the reward each time")
                1 -> T("نقاط لكل دقيقة", "Credit per minute")
                else -> T("نقاط ثابتة عند الإنجاز", "Fixed credit on completion")
            }
        }
        paint()
        val del: (() -> Unit)? = if (h == null) null else {
            {
                FocusStore.habits.remove(h)
                FocusStore.save(true)
                d.dismiss()
                render()
            }
        }
        col.addView(buttons(d, T("حفظ", "Save"), {
            val t = title.text.toString().trim()
            val v = if (kind == 0) 0.0 else (num(value.text.toString()) ?: 0.0)
            val targetMinutes = (num(target.text.toString()) ?: 25.0).toInt()
            if (t.isEmpty() || (kind != 0 && v <= 0.0) || targetMinutes !in 1..600) {
                Toast.makeText(this, T("أكمل الاسم والمكافأة، واجعل مدة الجلسة بين دقيقة و600 دقيقة", "Enter the name and reward, and set a session target from 1 to 600 minutes"), Toast.LENGTH_SHORT).show()
            } else {
                if (h != null) {
                    h.title = t
                    h.kind = kind
                    h.value = v
                    h.targetMinutes = targetMinutes
                } else FocusStore.habits.add(FHabit(Store.uid(), t, kind, v, targetMinutes = targetMinutes))
                FocusStore.save(true)
                d.dismiss()
                render()
            }
        }, del), Ui.lp(Ui.MP, Ui.WC, dp(14)))
        showDialog(d, col)
    }

    // اختيار تطبيق من التطبيقات القابلة للتشغيل (تُحمَّل في خيط خلفي)
    private fun pickApp(earn: Boolean) {
        Thread {
            val pm = packageManager
            val i = Intent(Intent.ACTION_MAIN)
            i.addCategory(Intent.CATEGORY_LAUNCHER)
            val taken = HashSet<String>()
            for (a in FocusStore.earn) taken.add(a.pkg)
            for (a in FocusStore.spend) taken.add(a.pkg)
            val seen = HashSet<String>()
            val list = ArrayList<PApp>()
            try {
                for (ri in pm.queryIntentActivities(i, 0)) {
                    val p = ri.activityInfo.packageName
                    if (p == packageName || p in taken || !seen.add(p)) continue
                    list.add(PApp(p, ri.loadLabel(pm).toString(), ri.loadIcon(pm)))
                }
            } catch (e: Exception) {
            }
            list.sortBy { it.name.lowercase() }
            act.runOnUiThread { if (!act.isFinishing) showPicker(list, earn) }
        }.start()
    }

    private fun showPicker(list: List<PApp>, earn: Boolean) {
        val d = newDialog()
        val col = column()
        col.addView(Ui.tv(this, T("اختر تطبيقًا", "Choose an app"), 17f, pal.fg, true))
        val q = edit(T("بحث", "Search"), "", false)
        col.addView(q, Ui.lp(Ui.MP, Ui.WC, dp(8)))
        val lst = LinearLayout(this)
        lst.orientation = LinearLayout.VERTICAL
        val sv = ScrollView(this)
        sv.addView(lst)
        col.addView(sv, Ui.lp(Ui.MP, dp(380), dp(8)))
        fun fill(f: String) {
            lst.removeAllViews()
            if (list.isEmpty()) lst.addView(Ui.tv(this, T("لا توجد تطبيقات متاحة", "No apps available"), 13f, pal.muted))
            for (a in list) {
                if (f.isNotEmpty() && !a.name.lowercase().contains(f)) continue
                val row = LinearLayout(this)
                row.orientation = LinearLayout.HORIZONTAL
                row.gravity = Gravity.CENTER_VERTICAL
                row.setPadding(0, dp(8), 0, dp(8))
                val ic = ImageView(this)
                ic.setImageDrawable(a.icon)
                row.addView(ic, LinearLayout.LayoutParams(dp(32), dp(32)))
                val nm = Ui.tv(this, a.name, 15f, pal.fg)
                nm.setPadding(dp(12), 0, 0, 0)
                row.addView(nm, LinearLayout.LayoutParams(0, Ui.WC, 1f))
                row.setOnClickListener {
                    d.dismiss()
                    rateDialog(null, earn, a.pkg, a.name)
                }
                lst.addView(row, Ui.lp(Ui.MP, Ui.WC))
            }
        }
        fill("")
        q.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                fill((s?.toString() ?: "").trim().lowercase())
            }
        })
        val close = Ui.btn(this, T("إلغاء", "Cancel"), Color.TRANSPARENT, pal.muted)
        close.setOnClickListener { d.dismiss() }
        col.addView(close, Ui.lp(Ui.MP, Ui.WC, dp(6)))
        showDialog(d, col)
    }
}

private class WeekBars(
    c: android.content.Context,
    val earn: DoubleArray,
    val spent: DoubleArray,
    val labels: Array<String>,
    val cEarn: Int,
    val cSpent: Int,
    val cText: Int
) : View(c) {
    private val p = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
    private var k = 1f

    // الأعمدة تنمو من القاعدة عند الظهور
    fun grow() {
        k = 0f
        val va = android.animation.ValueAnimator.ofFloat(0f, 1f)
        va.duration = 800
        va.startDelay = 300
        va.interpolator = android.view.animation.DecelerateInterpolator(1.6f)
        va.addUpdateListener {
            k = it.animatedValue as Float
            invalidate()
        }
        va.start()
    }

    override fun onDraw(cv: android.graphics.Canvas) {
        val d = resources.displayMetrics.density
        val w = width.toFloat()
        val h = height.toFloat()
        val chartH = h - 14f * d
        var mx = 1.0
        for (i in 0 until 7) mx = Math.max(mx, Math.max(earn[i], spent[i]))
        val col = w / 7f
        val bw = 7f * d
        p.textAlign = android.graphics.Paint.Align.CENTER
        p.textSize = 10f * d
        for (i in 0 until 7) {
            val cx = col * i + col / 2f
            p.color = cEarn
            val eh = (earn[i] / mx * (chartH - 2f * d)).toFloat() * k
            cv.drawRoundRect(cx - bw - d, chartH - eh, cx - d, chartH, 2f * d, 2f * d, p)
            p.color = cSpent
            val sh = (spent[i] / mx * (chartH - 2f * d)).toFloat() * k
            cv.drawRoundRect(cx + d, chartH - sh, cx + bw + d, chartH, 2f * d, 2f * d, p)
            p.color = cText
            cv.drawText(labels[i], cx, h - 2f * d, p)
        }
    }
}
