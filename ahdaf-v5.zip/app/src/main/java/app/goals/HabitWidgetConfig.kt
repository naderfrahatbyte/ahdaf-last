package app.goals

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

// شاشة اختيار عادات الودجت: عادة واحدة أو أكثر (بدون اختيار = كل العادات)
class HabitWidgetConfig : Activity() {
    private var wid = AppWidgetManager.INVALID_APPWIDGET_ID
    private val chosen = LinkedHashSet<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setResult(RESULT_CANCELED)
        Lang.load(this)
        wid = intent?.extras?.getInt(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID) ?: AppWidgetManager.INVALID_APPWIDGET_ID
        if (wid == AppWidgetManager.INVALID_APPWIDGET_ID) {
            finish()
            return
        }
        AppChrome.bars(this)
        val pal = PalGen.focus()
        val habits = HabitsData.all(this)
        val prev = (getSharedPreferences("hw", 0).getString("w" + wid, "") ?: "").split(",").filter { it.isNotBlank() }
        chosen.addAll(prev)
        val dp = { v: Int -> Ui.dp(this, v) }

        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.layoutDirection = Lang.dir
        box.setPadding(dp(20), dp(24), dp(20), dp(24))
        box.addView(Ui.tv(this, T("اختر عادات الودجت", "Choose widget habits"), 22f, pal.fg, true))
        box.addView(
            Ui.tv(this, T("عادة واحدة أو أكثر. عند اختيار أكثر من عادة تظهر خلف بعضها في المربع، وتنتقل بينها بلمس أسفل المربع. لو لم تختر شيئًا تظهر كل عاداتك.", "One or more habits. With several, they stack in the square and you tap the bottom of it to switch. Pick none to show all."), 13f, pal.muted),
            Ui.lp(Ui.MP, Ui.WC, dp(6))
        )
        if (habits.isEmpty()) {
            val hint = Ui.tv(this, T("لا توجد عادات بعد. أضف عادة من تبويب العادات في التطبيق، ثم ارجع واضغط على الودجت.", "No habits yet. Add a habit in the Habits tab, then tap the widget."), 14f, pal.fg)
            hint.setPadding(dp(14), dp(14), dp(14), dp(14))
            hint.background = Ui.shape(pal.glass, pal.line, dp(14).toFloat(), dp(1))
            box.addView(hint, Ui.lp(Ui.MP, Ui.WC, dp(16)))
        }
        for (h in habits) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(dp(14), 0, dp(14), 0)
            val mark = Ui.tv(this, "", 18f, pal.accent, true)
            mark.gravity = Gravity.CENTER
            val name = Ui.tv(this, h.title, 16f, pal.fg)
            name.setPadding(dp(12), 0, dp(12), 0)
            row.addView(mark, LinearLayout.LayoutParams(dp(28), dp(28)))
            row.addView(name, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            val paint = {
                val on = h.id in chosen
                mark.text = if (on) "✓" else ""
                mark.background = Ui.shape(if (on) PalGen.alpha(pal.accent, 50) else Color.TRANSPARENT, if (on) pal.accent else pal.line, dp(8).toFloat(), dp(2))
                row.background = Ui.shape(pal.glass, if (on) pal.accent else pal.line, dp(14).toFloat(), dp(1))
            }
            paint()
            row.setOnClickListener {
                if (h.id in chosen) chosen.remove(h.id) else chosen.add(h.id)
                paint()
            }
            box.addView(row, Ui.lp(Ui.MP, dp(56), dp(10)))
        }
        val done = Ui.btn(this, T("تم", "Done"), pal.accent, Color.parseColor("#1a1224"))
        done.minHeight = dp(52)
        done.setOnClickListener {
            val ids = habits.map { it.id }.filter { it in chosen }
            HabitWidget.saveSelection(this, wid, ids)
            HabitWidget.update(this, AppWidgetManager.getInstance(this), wid)
            setResult(RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, wid))
            finish()
        }
        box.addView(done, Ui.lp(Ui.MP, Ui.WC, dp(20)))

        val sv = ScrollView(this)
        sv.background = AppBgDrawable()
        sv.isFillViewport = true
        sv.addView(box)
        setContentView(sv)
    }
}
