package app.goals

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

// ملخّص عادة لعرضها في الودجت: week = آخر 7 أيام (0 غير مجدولة، 1 منجزة، 2 فائتة، 3 اليوم/قادمة)
class HabitInfo(
    val id: String, val title: String, val reward: Double, val minutes: Int,
    val done: Boolean, val streak: Int, val due: Boolean, val week: IntArray
)

// عادات الواجهة (S.habits في بيانات الويب): قراءة، تبديل إنجاز اليوم، ترحيل عادات Focus القديمة
object HabitsData {
    fun isoOf(day: Int): String {
        val c = civil(day)
        return String.format(java.util.Locale.US, "%04d-%02d-%02d", c[0], c[1], c[2])
    }

    // نفس ترقيم JS: 0 = الأحد
    private fun weekday(day: Int): Int = Math.floorMod(day + 4, 7)

    private fun dueOn(h: JSONObject, day: Int): Boolean {
        val d = h.optJSONArray("days")
        if (d == null || d.length() == 0) return true
        val w = weekday(day)
        for (i in 0 until d.length()) if (d.optInt(i, -1) == w) return true
        return false
    }

    private fun doneOn(h: JSONObject, day: Int): Boolean = h.optJSONObject("done")?.has(isoOf(day)) == true

    private fun streak(h: JSONObject): Int {
        val today = todayDay()
        var n = 0
        for (g in 0 until 400) {
            val d = today - g
            if (!dueOn(h, d)) continue
            if (doneOn(h, d)) n++ else if (d == today) continue else break
        }
        return n
    }

    fun all(c: Context): List<HabitInfo> {
        val arr = Store.data(c).optJSONArray("habits") ?: return emptyList()
        val today = todayDay()
        val out = ArrayList<HabitInfo>()
        for (i in 0 until arr.length()) {
            val h = arr.optJSONObject(i) ?: continue
            val week = IntArray(7) { k ->
                val d = today - 6 + k
                if (!dueOn(h, d)) 0 else if (doneOn(h, d)) 1 else if (d < today) 2 else 3
            }
            out.add(HabitInfo(h.optString("id"), h.optString("t"), h.optDouble("rw", 0.0), h.optInt("min", 0), doneOn(h, today), streak(h), dueOn(h, today), week))
        }
        return out
    }

    // يبدّل إنجاز اليوم ويمنح مكافأة Focus مرة واحدة في اليوم. يعيد true إن صارت منجزة
    fun toggleToday(c: Context, id: String): Boolean {
        val o = Store.data(c)
        val arr = o.optJSONArray("habits") ?: return false
        val key = isoOf(todayDay())
        for (i in 0 until arr.length()) {
            val h = arr.optJSONObject(i) ?: continue
            if (h.optString("id") != id) continue
            var done = h.optJSONObject("done")
            if (done == null) {
                done = JSONObject()
                h.put("done", done)
            }
            var rd = h.optJSONObject("rd")
            if (rd == null) {
                rd = JSONObject()
                h.put("rd", rd)
            }
            val now: Boolean
            if (done.has(key)) {
                done.remove(key)
                now = false
            } else {
                done.put(key, 1)
                now = true
                val rw = h.optDouble("rw", 0.0)
                if (rw > 0.0 && !rd.has(key)) {
                    FocusStore.init(c)
                    val a = FocusStore.add(rw, h.optString("t"), "h|" + id + "|" + key, false)
                    if (a > 0.0) rd.put(key, 1)
                }
            }
            Store.save(c, o)
            return now
        }
        return false
    }

    // عند إنهاء جلسة Focus لعادة: تُعتبر منجزة اليوم (المكافأة مُنحت عبر الجلسة نفسها)
    fun markDoneToday(c: Context, id: String) {
        val o = Store.data(c)
        val arr = o.optJSONArray("habits") ?: return
        val key = isoOf(todayDay())
        for (i in 0 until arr.length()) {
            val h = arr.optJSONObject(i) ?: continue
            if (h.optString("id") != id) continue
            var done = h.optJSONObject("done")
            if (done == null) {
                done = JSONObject()
                h.put("done", done)
            }
            var rd = h.optJSONObject("rd")
            if (rd == null) {
                rd = JSONObject()
                h.put("rd", rd)
            }
            done.put(key, 1)
            rd.put(key, 1)
            Store.save(c, o)
            return
        }
    }

    // مرة واحدة: ينقل عادات Focus القديمة إلى قسم العادات الجديد
    fun migrate(c: Context) {
        val sp = c.getSharedPreferences("g", 0)
        if (sp.getBoolean("habits_mig", false)) return
        sp.edit().putBoolean("habits_mig", true).apply()
        FocusStore.init(c)
        if (FocusStore.habits.isEmpty()) return
        val o = Store.data(c)
        var arr = o.optJSONArray("habits")
        if (arr == null) {
            arr = JSONArray()
            o.put("habits", arr)
        }
        val have = HashSet<String>()
        for (i in 0 until arr.length()) have.add(arr.optJSONObject(i)?.optString("id") ?: "")
        for (h in FocusStore.habits) {
            if (h.id in have) continue
            val rw = if (h.kind == 1) h.value * h.targetMinutes else if (h.kind == 2) h.value else 0.0
            arr.put(
                JSONObject().put("id", h.id).put("t", h.title).put("days", JSONArray()).put("rw", rw)
                    .put("min", h.targetMinutes).put("done", JSONObject()).put("rd", JSONObject()).put("cr", isoOf(todayDay()))
            )
        }
        Store.save(c, o)
    }
}
