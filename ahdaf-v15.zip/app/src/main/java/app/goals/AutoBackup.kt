package app.goals

import android.app.Activity
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import org.json.JSONObject

// نسخة احتياطية أسبوعية تلقائية في Download/Ahdaf (4 ملفات تتبدّل بالتناوب)، قابلة للاستيراد من الإعدادات
object AutoBackup {
    private const val WEEK = 7L * 24L * 3600L * 1000L

    fun lastTime(c: Context): Long = c.getSharedPreferences("backup", 0).getLong("last", 0L)

    private fun hasData(c: Context): Boolean {
        return try {
            val o = Store.data(c)
            (o.optJSONArray("goals")?.length() ?: 0) > 0 ||
                (o.optJSONArray("loose")?.length() ?: 0) > 0 ||
                (o.optJSONArray("lists")?.length() ?: 0) > 0 ||
                (o.optJSONArray("habits")?.length() ?: 0) > 0 ||
                FocusStore.habits.isNotEmpty() || FocusStore.earn.isNotEmpty() ||
                FocusStore.spend.isNotEmpty() || FocusStore.log.isNotEmpty()
        } catch (e: Exception) {
            false
        }
    }

    // تبني الملف على الخيط الحالي (سريع) وتكتبه في الخلفية، إلا إن طُلب التنفيذ المتزامن
    fun runIfDue(c: Context, sync: Boolean = false, force: Boolean = false): Boolean {
        try {
            val sp = c.getSharedPreferences("backup", 0)
            val now = System.currentTimeMillis()
            if (!force && now - sp.getLong("last", 0L) < WEEK) return false
            FocusStore.init(c)
            if (!hasData(c)) return false
            val full = JSONObject(Store.data(c).toString())
            full.put("focus", FocusStore.snapshot(c))
            full.put("savedAt", now)
            val bytes = full.toString().toByteArray(Charsets.UTF_8)
            val name = "ahdaf-auto-backup-" + (((now / WEEK) % 4L) + 1L) + ".json"
            val job = Runnable {
                try {
                    if (write(c, name, bytes)) sp.edit().putLong("last", now).apply()
                } catch (e: Exception) {
                }
            }
            if (sync) job.run() else Thread(job).start()
            return true
        } catch (e: Exception) {
            return false
        }
    }

    private fun write(c: Context, name: String, bytes: ByteArray): Boolean {
        if (Build.VERSION.SDK_INT >= 29) {
            val cr = c.contentResolver
            val coll = MediaStore.Downloads.EXTERNAL_CONTENT_URI
            var found: Uri? = null
            cr.query(
                coll, arrayOf(MediaStore.MediaColumns._ID),
                MediaStore.MediaColumns.DISPLAY_NAME + "=? AND " + MediaStore.MediaColumns.RELATIVE_PATH + " LIKE ?",
                arrayOf(name, "Download/Ahdaf%"), null
            )?.use { cur ->
                if (cur.moveToFirst()) found = ContentUris.withAppendedId(coll, cur.getLong(0))
            }
            if (found == null) {
                val v = ContentValues()
                v.put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                v.put(MediaStore.MediaColumns.MIME_TYPE, "application/json")
                v.put(MediaStore.MediaColumns.RELATIVE_PATH, "Download/Ahdaf")
                found = cr.insert(coll, v)
            }
            val u = found ?: return false
            val os = cr.openOutputStream(u, "wt") ?: return false
            os.use { it.write(bytes) }
            return true
        }
        val dir = c.getExternalFilesDir(null) ?: return false
        java.io.File(dir, name).writeBytes(bytes)
        return true
    }
}

// مسح كل البيانات (الأهداف والمهام والقوائم وFocus) مع الإبقاء على إعدادات الشكل واللغة
object DataReset {
    fun wipe(a: Activity) {
        DataSafe.snapshot(a, T("قبل مسح البيانات", "Before erase"))
        FocusStore.reset(a)
        a.getSharedPreferences("g", 0).edit().remove("d").apply()
        GoalsWidget.refresh(a)
        a.startActivity(Intent(a, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK))
        a.finish()
    }
}
