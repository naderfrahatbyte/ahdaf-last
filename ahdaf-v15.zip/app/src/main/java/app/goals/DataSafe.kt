package app.goals

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class SnapInfo(val file: String, val ts: Long, val label: String, val goals: Int, val tasks: Int, val habits: Int, val lists: Int)

class Counts(val goals: Int, val tasks: Int, val habits: Int, val lists: Int) {
    fun isEmpty(): Boolean = goals + tasks + habits + lists == 0
}

// حماية البيانات: نقاط استعادة محلية متدحرجة، ترحيل آمن بين الإصدارات، تنظيف الملفات المستوردة، واسترجاع تلقائي عند التلف
object DataSafe {
    const val CURRENT = 2
    private const val KEEP = 8
    private const val DIR = "snapshots"

    private fun dir(c: Context): File {
        val d = File(c.filesDir, DIR)
        if (!d.exists()) d.mkdirs()
        return d
    }

    fun counts(o: JSONObject): Counts {
        val ga = o.optJSONArray("goals")
        var tasks = o.optJSONArray("loose")?.length() ?: 0
        for (i in 0 until (ga?.length() ?: 0)) tasks += ga?.optJSONObject(i)?.optJSONArray("tasks")?.length() ?: 0
        return Counts(ga?.length() ?: 0, tasks, o.optJSONArray("habits")?.length() ?: 0, o.optJSONArray("lists")?.length() ?: 0)
    }

    // ---------- التنظيف والتحقق ----------
    private fun cleanTasks(a: JSONArray?, strict: Boolean): JSONArray {
        val out = JSONArray()
        if (a == null) return out
        val seen = HashSet<String>()
        for (i in 0 until a.length()) {
            val t = a.optJSONObject(i) ?: continue
            if (strict && t.optString("title").isBlank()) continue
            var id = t.optString("id")
            if (id.isBlank() || !seen.add(id)) {
                id = Store.uid()
                t.put("id", id)
                seen.add(id)
            }
            t.put("done", t.optBoolean("done", false))
            out.put(t)
        }
        return out
    }

    private fun cleanGoals(a: JSONArray?, strict: Boolean): JSONArray {
        val out = JSONArray()
        if (a == null) return out
        val seen = HashSet<String>()
        for (i in 0 until a.length()) {
            val g = a.optJSONObject(i) ?: continue
            if (strict && g.optString("title").isBlank()) continue
            var id = g.optString("id")
            if (id.isBlank() || !seen.add(id)) {
                id = Store.uid()
                g.put("id", id)
                seen.add(id)
            }
            g.put("tasks", cleanTasks(g.optJSONArray("tasks"), strict))
            out.put(g)
        }
        return out
    }

    private fun cleanLists(a: JSONArray?, strict: Boolean): JSONArray {
        val out = JSONArray()
        if (a == null) return out
        val seen = HashSet<String>()
        for (i in 0 until a.length()) {
            val l = a.optJSONObject(i) ?: continue
            if (strict && l.optString("title").isBlank()) continue
            var id = l.optString("id")
            if (id.isBlank() || !seen.add(id)) {
                id = Store.uid()
                l.put("id", id)
                seen.add(id)
            }
            l.put("items", cleanTasks(l.optJSONArray("items"), strict))
            out.put(l)
        }
        return out
    }

    private fun cleanHabits(a: JSONArray?, strict: Boolean): JSONArray {
        val out = JSONArray()
        if (a == null) return out
        val seen = HashSet<String>()
        for (i in 0 until a.length()) {
            val h = a.optJSONObject(i) ?: continue
            if (strict && h.optString("t").isBlank()) continue
            var id = h.optString("id")
            if (id.isBlank() || !seen.add(id)) {
                id = Store.uid()
                h.put("id", id)
                seen.add(id)
            }
            if (h.optJSONObject("done") == null) h.put("done", JSONObject())
            if (h.optJSONObject("rd") == null) h.put("rd", JSONObject())
            out.put(h)
        }
        return out
    }

    // يعيد نسخة نظيفة (v=CURRENT) أو null إن لم يكن الكائن بيانات تطبيق. strict = إسقاط العناصر بلا عنوان (للاستيراد)
    fun sanitize(o: JSONObject, strict: Boolean): JSONObject? {
        if (!o.has("goals") && !o.has("loose") && !o.has("lists") && !o.has("habits")) return null
        val out = JSONObject()
        out.put("v", CURRENT)
        out.put("goals", cleanGoals(o.optJSONArray("goals"), strict))
        out.put("loose", cleanTasks(o.optJSONArray("loose"), strict))
        out.put("lists", cleanLists(o.optJSONArray("lists"), strict))
        out.put("habits", cleanHabits(o.optJSONArray("habits"), strict))
        val keys = o.keys()
        while (keys.hasNext()) {
            val k = keys.next()
            if (!out.has(k)) out.put(k, o.get(k))
        }
        return out
    }

    // ---------- نقاط الاستعادة ----------
    // لا تُحفظ نقطة فارغة، حتى لا تطغى على نسخ جيدة
    fun snapshot(c: Context, label: String): Boolean {
        try {
            FocusStore.init(c)
            val o = Store.data(c)
            if (counts(o).isEmpty() && FocusStore.habits.isEmpty() && FocusStore.earn.isEmpty() && FocusStore.spend.isEmpty()) return false
            val now = System.currentTimeMillis()
            val full = JSONObject(o.toString())
            full.put("focus", FocusStore.snapshot(c))
            val wrap = JSONObject().put("ts", now).put("label", label).put("data", full)
            File(dir(c), "snap-" + now + ".json").writeText(wrap.toString(), Charsets.UTF_8)
            prune(c)
            c.getSharedPreferences("safe", 0).edit().putLong("last_snap", now).apply()
            return true
        } catch (e: Exception) {
            return false
        }
    }

    private fun prune(c: Context) {
        val files = dir(c).listFiles { f -> f.name.startsWith("snap-") && f.name.endsWith(".json") } ?: return
        val sorted = files.sortedByDescending { it.name }
        for (i in KEEP until sorted.size) {
            try {
                sorted[i].delete()
            } catch (e: Exception) {
            }
        }
    }

    fun list(c: Context): List<SnapInfo> {
        val files = dir(c).listFiles { f -> f.name.startsWith("snap-") && f.name.endsWith(".json") } ?: return emptyList()
        val out = ArrayList<SnapInfo>()
        for (f in files.sortedByDescending { it.name }) {
            try {
                val w = JSONObject(f.readText(Charsets.UTF_8))
                val cn = counts(w.getJSONObject("data"))
                out.add(SnapInfo(f.name, w.optLong("ts"), w.optString("label"), cn.goals, cn.tasks, cn.habits, cn.lists))
            } catch (e: Exception) {
            }
        }
        return out
    }

    // يستعيد نقطة: يحفظ الحالة الحالية أولًا حتى يمكن التراجع عن الاستعادة نفسها
    fun restore(c: Context, name: String): Boolean {
        try {
            if (name.contains("/") || name.contains("\\") || name.contains("..") || !name.startsWith("snap-")) return false
            val f = File(dir(c), name)
            val w = JSONObject(f.readText(Charsets.UTF_8))
            val clean = sanitize(JSONObject(w.getJSONObject("data").toString()), false) ?: return false
            snapshot(c, T("قبل الاستعادة", "Before restore"))
            val fo = clean.optJSONObject("focus")
            clean.remove("focus")
            if (fo != null) {
                FocusStore.init(c)
                FocusStore.restore(c, fo)
            }
            Store.save(c, clean)
            GoalsWidget.refresh(c)
            HabitWidget.refreshAll(c)
            MainActivity.notifyDataChanged()
            MainActivity.notifyFocusChanged()
            return true
        } catch (e: Exception) {
            return false
        }
    }

    // ---------- الترحيل والتشغيل ----------
    // بيانات تالفة (JSON غير صالح): نحفظ نصها كما هو ثم نستعيد آخر نقطة سليمة بدل أن يكتب التطبيق فوقها
    private fun recover(c: Context, raw: String) {
        try {
            File(dir(c), "corrupt-" + System.currentTimeMillis() + ".txt").writeText(raw, Charsets.UTF_8)
        } catch (e: Exception) {
        }
        val snaps = list(c)
        if (snaps.isNotEmpty() && restore(c, snaps[0].file)) {
            c.getSharedPreferences("safe", 0).edit().putString("recovered", snaps[0].label + " · " + snaps[0].goals + "/" + snaps[0].tasks + "/" + snaps[0].habits).apply()
        }
    }

    fun migrate(c: Context) {
        val raw = c.getSharedPreferences("g", 0).getString("d", "") ?: ""
        if (raw.isBlank()) return
        val o = try {
            JSONObject(raw)
        } catch (e: Exception) {
            recover(c, raw)
            return
        }
        if (o.optInt("v", 1) >= CURRENT) return
        snapshot(c, T("قبل ترحيل البيانات", "Before data migration"))
        val clean = sanitize(o, false) ?: return
        Store.save(c, clean)
    }

    @Suppress("DEPRECATION")
    private fun versionCode(c: Context): Int = try {
        c.packageManager.getPackageInfo(c.packageName, 0).versionCode
    } catch (e: Exception) {
        0
    }

    // عند فتح التطبيق: ترحيل/إصلاح، نقطة قبل أول تشغيل لإصدار جديد، ونقطة يومية
    fun onStart(c: Context) {
        try {
            migrate(c)
            val sp = c.getSharedPreferences("safe", 0)
            val now = System.currentTimeMillis()
            val vc = versionCode(c)
            val last = sp.getInt("last_vc", 0)
            if (last != vc) {
                if (last != 0) snapshot(c, T("قبل تحديث التطبيق", "Before app update"))
                sp.edit().putInt("last_vc", vc).apply()
            }
            if (now - sp.getLong("last_snap", 0L) > 20L * 3600000L) snapshot(c, T("تلقائية يومية", "Daily automatic"))
        } catch (e: Throwable) {
        }
    }

    // رسالة استرجاع تلقائي لمرة واحدة
    fun takeRecoveredMessage(c: Context): String? {
        val sp = c.getSharedPreferences("safe", 0)
        val m = sp.getString("recovered", null) ?: return null
        sp.edit().remove("recovered").apply()
        return m
    }

    fun fmtTime(ts: Long): String = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.US).format(java.util.Date(ts))
}
